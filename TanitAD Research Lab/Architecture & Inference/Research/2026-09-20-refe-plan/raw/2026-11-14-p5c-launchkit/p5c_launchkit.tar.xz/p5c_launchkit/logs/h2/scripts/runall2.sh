#!/bin/bash
# usage: runall2.sh <tree root> <label> <list file>  -- SERIAL, per-test TMP under scratch deleted after each; stops if C: free < 10 GB
TREE="$1"; LABEL="$2"; LIST="$3"
P="TanitAD Research Lab/Architecture & Inference/Research/2026-09-20-refe-plan"
OUT="C:/Users/Admin/p5ck2/work/res/$LABEL"; mkdir -p "$OUT"
PY="C:/Users/Admin/venvs/tanitad/Scripts/python.exe"
export CUDA_VISIBLE_DEVICES=-1 PYTHONUTF8=1
SUM="$OUT/_summary.txt"; : > "$SUM"
cd "$TREE/$P/refe" || exit 9
while read -r name tmo args; do
  [ -z "$name" ] && continue
  case "$name" in \#*) continue;; esac
  free=$(df -BG /c | awk 'NR==2{gsub("G","",$4); print $4}')
  if [ "$free" -lt 10 ]; then echo "STOP C: free ${free}G < 10G before $name" >> "$SUM"; exit 8; fi
  T="C:/Users/Admin/p5ck2/work/tmp_$LABEL"; rm -rf "$T"; mkdir -p "$T"
  tag="${name%.py}$(echo "$args" | tr -d ' -')"
  t0=$(date +%s)
  TMP="$T" TEMP="$T" TMPDIR="$T" timeout "$tmo" "$PY" "$name" $args > "$OUT/$tag.log" 2>&1 < /dev/null
  rc=$?
  t1=$(date +%s)
  tok=$(grep -aoE "ZZ[A-Z0-9_-]*PASS[A-Z0-9_-]*( [0-9]+)?" "$OUT/$tag.log" | tail -1)
  skips=$(grep -ac "^ZZTEST_SKIP" "$OUT/$tag.log")
  echo "$name $args rc=$rc $((t1-t0))s tok=[$tok] skips=$skips" >> "$SUM"
  rm -rf "$T"
done < "$LIST"
echo DONE >> "$SUM"
