import pathlib
T = "C:/Users/Admin/p5ck/work/tipA/TanitAD Research Lab/Architecture & Inference/Research/2026-09-20-refe-plan/refe/"
K = "E:/Projects/TanitAD-artifacts/scorer_gym_20261107/p5c_launchkit/files/TanitAD Research Lab/Architecture & Inference/Research/2026-09-20-refe-plan/refe/"
NEW = '"refe_p5c", "refe_p5c_c0", "refe_p5c_c0r"'
def edit(name, pairs):
    s = pathlib.Path(T + name).read_text(encoding="utf-8")
    for a, b in pairs:
        assert s.count(a) == 1, (name, a[:60], s.count(a))
        s = s.replace(a, b)
    pathlib.Path(K + name).write_text(s, encoding="utf-8", newline="\n")
edit("test_div_gate.py", [('== {"refe_div_p6", "refe_vdac_p6"} and len(L.PROFILES) == 26', '== {"refe_div_p6", "refe_vdac_p6", ' + NEW + '} and len(L.PROFILES) == 29')])
edit("test_dose_gate.py", [('== {"refe_dose_s1z_p6", "refe_div_p6", "refe_vdac_p6"} and len(L.PROFILES) == 26', '== {"refe_dose_s1z_p6", "refe_div_p6", "refe_vdac_p6", ' + NEW + '} and len(L.PROFILES) == 29')])
edit("test_rep_gate.py", [('assert len(L.PROFILES) == 26 and len(set(L.PROFILES) - {"refe_rep_p6", ', 'assert len(L.PROFILES) == 29 and len(set(L.PROFILES) - {' + NEW + ', "refe_rep_p6", ')])
edit("test_s1zsm_gate.py", [('"refe_div_p6", "refe_vdac_p6"}, set(L.PROFILES) - set(TIP_FP)', '"refe_div_p6", "refe_vdac_p6", ' + NEW + '}, set(L.PROFILES) - set(TIP_FP)')])
edit("test_scorer1p6_gate.py", [('"refe_div_p6", "refe_vdac_p6"}, set(L.PROFILES) - set(PINNED_FP)', '"refe_div_p6", "refe_vdac_p6", ' + NEW + '}, set(L.PROFILES) - set(PINNED_FP)')])
edit("test_vdac_gate.py", [('== {"refe_vdac_p6"} and len(L.PROFILES) == 26', '== {"refe_vdac_p6", ' + NEW + '} and len(L.PROFILES) == 29')])
edit("test_p7_integration.py", [('for nm, prof in L.PROFILES.items() if nm != "refe_p7"),', 'for nm, prof in L.PROFILES.items() if nm != "refe_p7" and not nm.startswith("refe_p5c")),')])
print("ok")
