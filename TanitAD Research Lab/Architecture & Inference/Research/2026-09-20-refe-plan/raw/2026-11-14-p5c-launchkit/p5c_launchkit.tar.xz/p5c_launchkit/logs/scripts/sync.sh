#!/bin/bash
P="TanitAD Research Lab/Architecture & Inference/Research/2026-09-20-refe-plan"
K="E:/Projects/TanitAD-artifacts/scorer_gym_20261107/p5c_launchkit/files/$P"
cp "$K"/refe/*.py "C:/Users/Admin/p5ck/work/ovB/$P/refe/"
