import pathlib
p = pathlib.Path("E:/Projects/TanitAD-artifacts/scorer_gym_20261107/p5c_launchkit/files/TanitAD Research Lab/Architecture & Inference/Research/2026-09-20-refe-plan/refe/gate_checks.py")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:50])
    s = s.replace(a, b)


rep('''"flag": "--traj-label-table", "declared": pin, "built": got, "how": "the table file's sha256 against the profile's registered pin",
                     "ok": got == pin})
    return rows
''', '''"flag": "--traj-label-table", "declared": pin, "built": got, "how": "the table file's sha256 against the profile's registered pin",
                     "ok": got == pin})
    pol_pin = (profile or {}).get("traj_label_rank_policy")          # P5-C card 4.3 / 10.1: the table's DECLARED rank policy is what 4.3's rule decided (the MM fills the pin from the gate set's output), not what the file happens to say
    if declared and pol_pin:
        try:
            import traj_label_table as _TLT
            got_pol = _TLT.load(declared).meta.get("rank_policy")
        except Exception as e:                                          # noqa: BLE001 -- an unloadable table is a red row, never a skip
            got_pol = f"unloadable: {type(e).__name__}: {str(e)[:120]}"
        rows.append({"dest": "traj_label_table", "flag": "--traj-label-table", "declared": pol_pin, "built": got_pol,
                     "how": "the table's meta.rank_policy against the profile's registered traj_label_rank_policy", "ok": got_pol == pol_pin})
    return rows


def p5c_init_rows(a, profile=None) -> list:
    """P5-C card 10.1 G-DVB `init_from`: the base checkpoint's file sha256 == the profile's registered `init_from_sha256` (P5C_BASE_SHA256: P7's final, or P6's 968a469d... under B-P6).
    Only a profile that registers the pin is asked (every other profile's rows are unchanged); the registration itself is made mandatory by launch_gate.p5c_refusals, so an unfilled pin refuses
    BEFORE any build and this row can never be the only line of defence."""
    pin = (profile or {}).get("init_from_sha256")
    declared = getattr(a, "init_from", None) or None
    if not pin or not declared:
        return []
    try:
        got = hashlib.sha256(Path(declared).read_bytes()).hexdigest()
    except OSError as e:
        got = f"unreadable: {e}"
    return [{"dest": "init_from", "flag": "--init-from", "declared": pin, "built": got, "how": "the base checkpoint file's sha256 against the profile's registered init_from_sha256", "ok": got == pin}]
''')
rep('''    rows += traj_label_dvb_rows(a, b, profile)
    return rows''', '''    rows += traj_label_dvb_rows(a, b, profile)
    rows += p5c_init_rows(a, profile)
    return rows''')
rep('''required=bool(profile.get("p7_rules")))''', '''required=bool(profile.get("p7_rules") or profile.get("p5c_rules")))''')
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
