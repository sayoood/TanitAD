"""REFe training loop, with an OVERFIT TEST as its control.

THE CONTROL, and why it is the right one for a training loop. A loop can run, print a falling
average, and still be broken -- the optimizer holding no trainable tensors, the graph detached, the
target mis-shaped. The discriminating check is whether it can DRIVE THE LOSS TO ~0 ON A HANDFUL OF
SAMPLES. A correct loop memorises 8 tuples easily; a broken one plateaus. It also ships a
deliberate-regression arm (`--break-optimizer`) that hands the optimizer an empty parameter set: if
the overfit test still "passes" under that, the test is inert and proves nothing.

IMAGES. `--synthetic` substitutes deterministic noise images keyed by the tuple index, for validating
the MECHANICS before the bulk CAM_F0 fetch lands. It is deliberately loud: any run started with it
prints that its loss numbers are about the loop and not about driving.

Usage:
  python train.py --overfit --synthetic              # the control, ~1 min on the 4060
  python train.py --overfit --synthetic --break-optimizer   # must FAIL
  python train.py --targets <dir> --images <root> --steps 2000
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

sys.path.insert(0, str(Path(__file__).resolve().parent))
from model import BACKBONES, REFe, REFeConfig, param_report, wta_loss  # noqa: E402
from field_loss import field_loss  # noqa: E402  (L_field, eval/PREREG_AUX_FIELD_LOSS_DRAFT.md: only called when --w-field > 0; the label reader is imported lazily by TargetBank)
import ckpt_io  # noqa: E402
import nav_command as NC  # noqa: E402
import traj_label_table as TLT  # noqa: E402  (P5-C: the row -> Tc20s trajectory label table behind --traj-label-table; stdlib only, nothing is read unless the flag is set)
import ego_yaw_table as EYT  # noqa: E402  (WP YAW: the token -> nuPlan ego_pose.angular_rate_z table behind --ego-yaw-table; imports only the stdlib, and nothing is read unless the flag is set)
import aux_drivable_head as AUX  # noqa: E402  (P7.1, SPEC_AUX_DRIVABLE_HEAD.md: the TRAINING-ONLY drivable-area head. Built ONLY under --aux-drv; the module imports no map API and no label-store code at import time)


CAMERAS = ("CAM_F0", "CAM_L0", "CAM_R0", "CAM_B0")


class FrameStore:
    """Read a frame from ANY of the rig's cameras, from a loose file OR a per-(log, camera) zip.

    exFAT on D: uses 1 MiB allocation units, so 26,060 loose 204 KB JPEGs cost 25 GB of disk for
    5.08 GB of data (MEASURED, 5.0x). Containers remove that because the loss is per FILE. Handles
    are cached per log; a zip read is a seek plus a copy, so this is not slower in practice.

    ⛔ TWO FOUR-CAMERA DEFECTS FIXED HERE 2026-09-21 (Review 5, D8).

    1. The container path was hardcoded to `{log_name}_CAM_F0.zip`, so under four cameras every
       L0/R0/B0 frame missed its container.
    2. Worse, and the reason this was a silent failure rather than a slow one: on `KeyError` it
       **returned None instead of falling through** to the loose-file path below. So the mere
       PRESENCE of a `_CAM_F0.zip` at the root made every non-front frame unreadable **even when
       its loose file was sitting right there** — a container for one camera disabling the other
       three. The container lookup is now a *try*, never a verdict.
    """

    def __init__(self, root: str | None):
        self.root = root
        self._zips: dict[str, object] = {}
        self._members: dict[str, set] = {}          # container -> member names, read once
        self._containers: set | None = None         # containers present at root, listed ONCE
        self._index: dict[str, str] | None = None   # basename -> path of every loose frame, ONCE

    def container_set(self) -> set:
        """The `<log>_<CAM>.zip` containers at the root, from ONE directory listing.

        Before 2026-09-23 every frame probed four container paths with `os.path.exists`, i.e. 16
        stats per 4-camera sample for containers that, on the pod's loose layout, never exist.
        """
        if self._containers is None:
            try:
                self._containers = ({n for n in os.listdir(self.root) if n.endswith(".zip")}
                                    if self.root and os.path.isdir(self.root) else set())
            except OSError:
                self._containers = set()
        return self._containers

    def index(self) -> dict:
        """basename -> path for every loose frame under the root, built ONCE by one walk.

        ⛔⛔ THIS REPLACES A RECURSIVE GLOB THAT RAN PER IMAGE (R21, 2026-09-23). OpenScene's
        `navtrain_current_N.tgz` extracts as `navtrain_current_N/<log>/<CAM>/<hash>.jpg`, while a
        row names `<log>/<CAM>/<hash>.jpg` -- so the direct path always MISSED on the pod and every
        read fell through to `glob(root/**/name)`: a walk of the whole ~400 K-file pixel tree, four
        times per sample, for ~4.4 M sample-passes. Nothing errors -- the run is just slower by a
        factor set by the tree size. The member name is a per-image 64-bit hash, so a basename
        index is exact regardless of how deep the extraction put it.
        """
        if self._index is None:
            idx: dict[str, str] = {}
            if self.root and os.path.isdir(self.root):
                for dp, _dn, fns in os.walk(self.root):
                    for fn in fns:
                        if fn.endswith((".jpg", ".jpeg", ".png")):
                            idx.setdefault(fn, os.path.join(dp, fn))
            self._index = idx
        return self._index

    def _member_set(self, zp: str) -> set:
        if zp not in self._members:
            z = self._open(zp)
            try:
                self._members[zp] = set(z.namelist()) if z is not None else set()
            except Exception:
                self._members[zp] = set()
        return self._members[zp]

    def resolvable(self, image_ref: str, log_name: str) -> bool:
        """Would `read` find this frame? Answered from the listings -- never a per-frame stat."""
        if "::" in image_ref:
            zp, member = image_ref.split("::", 1)
            if member in self._member_set(zp):
                return True
        name = os.path.basename(image_ref.split("::", 1)[-1])
        if self.root:
            have = self.container_set()
            for c in CAMERAS:
                fn = f"{log_name}_{c}.zip"
                if fn in have and name in self._member_set(os.path.join(self.root, fn)):
                    return True
            return name in self.index()
        return os.path.isabs(image_ref) and os.path.exists(image_ref)

    @staticmethod
    def camera_of(image_ref: str) -> str | None:
        for c in CAMERAS:
            if c in image_ref:
                return c
        return None

    def _open(self, zp: str):
        import zipfile
        z = self._zips.get(zp)
        if z is None and os.path.exists(zp):
            try:
                z = self._zips[zp] = zipfile.ZipFile(zp)
            except Exception:
                return None
        return z

    def read(self, image_ref: str, log_name: str) -> bytes | None:
        # build_targets.index_images emits "<container.zip>::<member>" for containerised frames
        if "::" in image_ref:
            zp, member = image_ref.split("::", 1)
            z = self._open(zp)
            if z is not None:
                try:
                    return z.read(member)
                except KeyError:
                    pass                      # fall through rather than declare the frame missing
        name = os.path.basename(image_ref)
        if self.root:
            cam = self.camera_of(image_ref)
            have = self.container_set()
            # try this frame's own camera first, then every other channel's container: the member
            # name is a per-image hash, so a hit in the "wrong" container is still the right image.
            for c in ([cam] if cam else []) + [c for c in CAMERAS if c != cam]:
                if f"{log_name}_{c}.zip" not in have:
                    continue                  # listed once at start: absent containers cost nothing
                z = self._open(os.path.join(self.root, f"{log_name}_{c}.zip"))
                if z is None:
                    continue
                try:
                    return z.read(name)
                except KeyError:
                    continue                  # ⛔ was `return None` -- see the docstring
        p = image_ref if os.path.isabs(image_ref) else os.path.join(
            self.root or "", *image_ref.split("/"))
        if os.path.exists(p):
            with open(p, "rb") as f:
                return f.read()
        q = self.index().get(name) if self.root else None
        if q is not None:
            with open(q, "rb") as f:
                return f.read()
        return None


KMAX = 16          # padding width for the per-frame candidate set (the set is 8-9 today)

# ⛔ WHY THE CANDIDATE NAME HAS TO SURVIVE INTO THE LOOP. `assign_d`, the distance from a banked
# candidate to the model proposal it is attached to, has a FLOOR THAT IS NOT ZERO and is set by the
# candidate set, not by model quality: a competent planner will never propose the `over-curb` path,
# so that row stays far away however well training goes. A single pooled mean therefore cannot
# distinguish "the supervision is landing" from "the model is bad", and would read as a permanent
# failure either way. Per-candidate is the only reading that separates them: `teacher` and `lat+-2`
# SHOULD converge, `over-curb` and `stopped` SHOULD NOT.
CAND_NAMES = ("teacher", "lat-4", "lat-2", "lat+2", "lat+4",
              "lon x0.5", "lon x1.5", "stopped", "jerky", "reverse", "over-curb")
CAND_INDEX = {n: i for i, n in enumerate(CAND_NAMES)}


def _scorer_files(path) -> list:
    """The scorer bank's files: every `scorer_targets*.jsonl` of a directory, or one named file."""
    if not path:
        return []
    if os.path.isdir(path):
        return sorted(glob.glob(os.path.join(path, "scorer_targets*.jsonl")))
    return [path] if os.path.isfile(path) else []


# ⭐ GROWING BANK (2026-09-24; PI: "try to parallelize training and data prep"). With --grow the run
# starts while the augmentation search and the scorer are still producing rows, and RE-READS the bank
# at every epoch boundary. What one epoch reads is fixed by a BYTE SNAPSHOT of every bank file taken
# at that boundary and stored in the checkpoint: a resume inside the epoch rebuilds the identical
# bank, and rows appended after the snapshot simply belong to a later epoch. The bank files are
# append-only (code/grow_assemble.py), which is what makes a byte length a complete description.
def bank_snapshot(targets_dir: str, scorer_path, onpolicy_path=None) -> dict:
    snap = {}
    for q in sorted(Path(targets_dir).glob("targets_rank*.jsonl")):
        snap["t:" + q.name] = q.stat().st_size
    for q in _scorer_files(scorer_path):
        snap["s:" + os.path.basename(q)] = os.path.getsize(q)
    # on-policy mode only (None in fixed mode, so a fixed run's snapshot is byte-for-byte unchanged)
    for q in _onpolicy_files(onpolicy_path):
        snap["o:" + os.path.basename(q)] = os.path.getsize(q)
    return snap


def read_upto(path, nbytes: int) -> list:
    """The complete lines in the first `nbytes` of `path`; a trailing partial line is not a row."""
    size = os.path.getsize(path)
    if size < nbytes:
        raise SystemExit(f"bank file {path} is SHORTER ({size:,} B) than its snapshot ({nbytes:,} B): "
                         f"it was rewritten, so it is no longer the bank this run trained on")
    with open(path, "rb") as f:
        buf = f.read(nbytes)
    cut = buf.rfind(b"\n")
    return [] if cut < 0 else [l for l in buf[:cut + 1].decode("utf-8").splitlines() if l.strip()]


class ScorerBank:
    """The six-component PDM targets, keyed by (log_name, step). Built by build_scorer_targets.py.

    ⛔ THE APPROXIMATION, STATED RATHER THAN HIDDEN. DriveZero scores the STUDENT'S OWN 64
    proposals online; we precompute targets for a fixed candidate set and attach each candidate's
    target to the model proposal NEAREST to it. The supervision is therefore only as good as that
    assignment, so the training loop REPORTS the mean assignment distance every log line. A large
    distance means the scorer is being taught about trajectories the model does not produce.

    ⛔ AND AN INERT COMPONENT IS WORSE THAN A MISSING ONE, so this class measures the per-component
    variance across the whole bank at load time and names any component that never varies. A
    constant target trains a constant bias and looks exactly like a component that has been
    learned. MEASURED 2026-09-20: `goal_reaching` is constant across every candidate including a
    stationary ego, which is why this check exists.
    """

    # ⛔ THE OLD TUPLE WAS ("off_road", "collision", "ttc", "comfort", "goal_reaching",
    # "center_line") AND TWO OF ITS SLOTS WERE MIS-MAPPED, which is worse than being wrong: the
    # names read as the paper's components, so nobody re-checked them.
    #   * `goal_reaching` stood in for PROGRESS. It is a TERMINAL indicator of coming within 3.0 m
    #     of a goal point >= 60 m ahead, so over a 4.0 s candidate it fires for whichever travels
    #     furthest -- it REWARDED OVERSPEED (lon x1.5 45/74 vs teacher 13/74).
    #   * `center_line` stood in for DRIVING-DIRECTION COMPLIANCE. It is lateral deviation with
    #     heading explicitly unused, while the real DDC detector writes categories 3 and 4 into
    #     `OffRoad.info` -- which we never read, so DDC supervision was ZERO.
    # These are the paper's own six, in its own words.
    COMPONENTS = ("collision", "drivable_area", "progress", "ttc", "comfort", "ddc")

    def __init__(self, path: str, sizes: dict | None = None):
        self.by: dict = {}
        self.n_rows = 0
        self.files: list = []
        self.n_legacy_norank = 0
        # a DIRECTORY loads every shard: parallel builder passes at different frame offsets each
        # write their own file, and a bank assembled from shards must not depend on which one you
        # happened to name.
        files = _scorer_files(path)
        if not files:
            return
        if sizes is not None:                   # --grow: exactly the epoch snapshot's files + bytes
            files = [f for f in files if "s:" + os.path.basename(f) in sizes]
        self.files = files
        for fpath in files:
          with open(fpath, encoding="utf-8") as fh:
            src = (read_upto(fpath, sizes["s:" + os.path.basename(fpath)]) if sizes is not None
                   else fh)
            for line in src:
                r = json.loads(line)
                # ⛔ THE KEY MUST CARRY THE TOKEN. `log_name` is the DRIVE LOG, and one drive log
                # holds SEVERAL scenarios: MEASURED 2026-09-20, 50 of 154 (log, step) keys collided,
                # one log carrying 3 distinct tokens and another 2. Keyed without the token, a
                # frame's candidates were silently pooled with a DIFFERENT scenario's candidates at
                # the same step index, and the scorer was supervised on trajectories belonging to
                # another scene. ⭐ It was caught by ARITHMETIC, not by reading the code: the
                # per-candidate report showed `teacher` with n = 837 against only 605 covered
                # samples, which is impossible when each sample contributes one teacher row. It also
                # inflated the teacher's assignment distance to 5.73 m while the winner-takes-all
                # distance to the same trajectory was 0.57.
                # ⛔ AND THE RANK. The paper requires the navigation command, the teacher
                # trajectory and the proposal scores to be MUTUALLY CONSISTENT -- all three from
                # the SAME augmented route. A key without the rank hands a rank-1 training tuple
                # the rank-0 proposal scores, which is a silent mislabelling that no loss curve can
                # show. MEASURED 2026-09-20 by the conformance review: 540 of 1,080 covered tuples
                # were exactly that, while the two routes' goals differed in 1,064/1,091 tuples
                # (median 3.80 m, max 28.84 m) and their teacher targets by a median of 2.418 m.
                # ⚠️ A row with no `rank` field predates the fix. The earlier version of this
                # comment said the rank-0 assumption "is asserted in the builder's stats file" --
                # ⛔ and NO CODE READS THAT FILE, and it is not rank-suffixed either, so the
                # assertion existed only in prose. That is the same shape as an allow-list entry
                # nobody re-reads. A legacy row is now COUNTED and reported at load time, so the
                # assumption is visible in the run rather than buried in a comment.
                k = (r["log_name"], r.get("token", ""), int(r["step"]), int(r.get("rank", 0)))
                e = self.by.setdefault(k, {"traj": [], "tgt": [], "name": []})
                if "rank" not in r:
                    self.n_legacy_norank += 1
                e["traj"].append(r["traj"])
                e["tgt"].append(self.components(r["targets"]))
                e["name"].append(r["candidate"])
                self.n_rows += 1

    @staticmethod
    def components(t: dict) -> list:
        """PDM convention: 1.0 = NO violation, 0.0 = violation. Soft values stay soft."""
        def g(k, d=0.0):
            v = t.get(k, d)
            if v is None:
                return d
            try:
                return float(v)
            except Exception:
                return d
        clip = lambda x: min(max(x, 0.0), 1.0)          # noqa: E731
        # ⛔ `OffRoad.info` IS A CATEGORY, NOT A FLAG: 0 none / 1 off-road / 2 solid-line crossing
        # / 3 wrong-way / 4 severe wrong-way. The old code did `1 - clip(info)`, which collapses
        # 2, 3 and 4 onto the same value as 1 and silently destroys the distinction. Harmless while
        # only {0, 1} occur in the bank, and live the moment a richer scene appears. Compare the
        # category explicitly instead.
        # the two questions are now derived per PREFIX in score_proposals and aggregated as
        # booleans, so this consumer no longer re-reads a max-aggregated nominal category
        dac_viol = g("dac.violation", None)
        ep = g("progress.ep", float("nan"))
        return [
            1.0 - clip(g("collision.NuPlanCollision.info")),        # collision avoidance
            (1.0 - clip(dac_viol)) if dac_viol is not None                 # drivable-area
            else (0.0 if int(round(g("off_road.OffRoad.info"))) == 1 else 1.0),
            clip(ep) if ep == ep else 1.0,                          # progress (EP, teacher-relative)
            clip(g("ttc.NuPlanTTC.ttc_reward", 1.0)),               # time to collision
            clip(g("comfort.Comfort.reward", 1.0)),                 # comfort
            1.0 - clip(g("ddc.violation")),                         # driving-direction compliance
        ]

    def variance_report(self):
        """Can each component RANK PROPOSALS? That is a WITHIN-FRAME question.

        ⛔ THIS GUARD WAS WRONG AND A DOC QUOTED IT AS PROOF. The first version pooled every row in
        the bank and reported one standard deviation per component. A component that is CONSTANT
        across the candidates of every single frame, and merely differs between frames, then shows
        a healthy pooled spread and passes -- while being completely unable to rank anything.
        MEASURED 2026-09-20 by the conformance review: `comfort` varies across candidates in
        **0 of 540 frames** and the pooled guard passed it at sd 0.1111, which `REFE_MODEL.md` then
        cited as evidence that all six components discriminate.
        ⭐ The scorer's job is to choose among the candidates OF ONE FRAME, so the only measurement
        that answers the question is the spread WITHIN a frame. This reports the fraction of frames
        in which each component varies at all, and names anything below 5 % as unable to rank.
        Same family as the four self-referential checks of 2026-09-07: a check whose question is
        narrower than the claim hung on it.
        """
        if not self.by:
            return []
        import statistics
        n_frames = len(self.by)
        out = []
        for i, name in enumerate(self.COMPONENTS):
            vals, n_vary = [], 0
            for e in self.by.values():
                col = [row[i] for row in e["tgt"]]
                vals += col
                if len(col) > 1 and (max(col) - min(col)) > 1e-9:
                    n_vary += 1
            frac = n_vary / max(n_frames, 1)
            pooled = statistics.pstdev(vals) if len(vals) > 1 else 0.0
            out.append((name, sum(vals) / len(vals), pooled, frac, frac < 0.05))
        return out

    def get(self, log_name: str, token: str, step: int, rank: int = 0):
        e = self.by.get((log_name, token, int(step), int(rank)))
        if e is None:
            return None
        return e["traj"], e["tgt"], e["name"]


def _onpolicy_files(path) -> list:
    """The on-policy bank's files: every `onpolicy_*.jsonl` of a directory. ⛔ The name must NOT match
    `scorer_targets*.jsonl`: a fixed-mode trainer globs that pattern in its scorer dir and would take
    these rows as extra fixed candidates -- silently changing a live run's recipe."""
    if not path or not os.path.isdir(path):
        return []
    return sorted(glob.glob(os.path.join(path, "onpolicy_*.jsonl")))


class OnPolicyBank:
    """The student's OWN proposals, scored by the teacher's simulator -- the paper's scorer supervision.

    ⭐ PI DECISION 2026-09-26 (option B, "the paper version"), after SPEC_NAVTEST E-6 measured the
    fixed-candidate scorer at ~0 selection skill (best of 64 91.2 PDMS, pick 43.8, random 43.2).
    `onpolicy_dump.py` (pod GPU) writes a recent checkpoint's 64 proposals per training sample;
    `onpolicy_label.py` (pod CPUs, low priority) scores each with the SAME calculators, stride,
    logged context, per-row route and teacher-relative EP as `build_scorer_targets.py`. The trainer
    feeds a sample's labelled SET through the scoring decoder (`REFe.forward(score_extra=...)`), so
    every label meets the exact trajectory it was computed for: no nearest-proposal assignment and
    no drift. Declared residual departures: labels come from a checkpoint up to a few hours old, and
    only for the samples labelled so far.

    ONE LINE PER SAMPLE (`kind: onpolicy_set`): all n_prop trajectories [M][T][2] + yaws [M][T] and
    their M raw target dicts, turned into the six components by `ScorerBank.components` -- the same
    function the fixed bank uses, so the two modes cannot disagree on what a target means. A line is
    all-or-nothing: the scoring decoder's self-attention spans the SET, so a partial set would be
    scored in the wrong context. A key keeps the newest `ckpt_step`. Arrays are float32 numpy: as
    Python lists a full-scale bank would cost GBs in every DataLoader worker.
    """

    def __init__(self, path: str, n_prop: int, horizon: int, sizes: dict | None = None, lane_labels: str | None = None,
                 pdm_labels: str | None = None, teacher_lane_labels: str | None = None, pdm_only: bool = False):
        self.by: dict = {}
        self.n_rows = self.n_incomplete = self.n_superseded = self.n_bad_lines = self.n_navsim_dac = 0
        files = _onpolicy_files(path)
        if sizes is not None:
            files = [f for f in files if "o:" + os.path.basename(f) in sizes]
        self.files = files
        for fpath in files:
            with open(fpath, encoding="utf-8") as fh:
                src = (read_upto(fpath, sizes["o:" + os.path.basename(fpath)]) if sizes is not None
                       else fh)
                for line in src:
                    # ⛔ a labeller killed mid-write can leave ONE torn line; the labeller terminates
                    # it on restart. It must cost that sample, never the run at an epoch boundary.
                    try:
                        r = json.loads(line)
                    except json.JSONDecodeError:
                        self.n_bad_lines += 1
                        continue
                    if r.get("kind") != "onpolicy_set":
                        continue
                    self.n_rows += 1
                    try:
                        xy = np.asarray(r["traj"], np.float32)
                        yw = np.asarray(r["yaw"], np.float32)
                        tg = np.asarray([ScorerBank.components(t) for t in r["targets"]], np.float32)
                    except (KeyError, ValueError, TypeError):
                        self.n_incomplete += 1
                        continue
                    if (xy.shape != (n_prop, horizon, 2) or yw.shape != (n_prop, horizon)
                            or tg.shape != (n_prop, 6) or not np.isfinite(xy).all()):
                        self.n_incomplete += 1
                        continue
                    # ⭐ NAVSIM-FAITHFUL DRIVABLE AREA (PI decision 2026-09-26). The teacher's
                    # `dac.violation` is DriveRL's CURB-CROSSING detector: MEASURED 0-1 % on paths
                    # shifted 2-4 m, 12 % on a path aimed through a curb, 0 of 1,024 of the model's
                    # own proposals -- against NAVSIM's footprint-in-drivable-polygons check, which
                    # fails 33 % of them. A set whose EVERY proposal carries `navsim_dac.violation`
                    # (label_version >= 2) takes that as its drivable-area component instead.
                    has_nd = all(isinstance(t, dict) and "navsim_dac.violation" in t for t in r["targets"])
                    if has_nd:
                        tg[:, 1] = 1.0 - np.clip(np.asarray(
                            [float(t["navsim_dac.violation"]) for t in r["targets"]], np.float32), 0.0, 1.0)
                    k = (r["log_name"], r.get("token", ""), int(r["step"]), int(r.get("rank", 0)))
                    # newest checkpoint first, then the newest label version (a relabelled set with
                    # the NAVSIM drivable area supersedes the same proposals' teacher-only labels)
                    rank_key = (int(r["ckpt_step"]), int(r.get("label_version", 1)))
                    prev = self.by.get(k)
                    if prev is not None:
                        self.n_superseded += 1
                        if prev[3] >= rank_key:
                            continue
                    self.by[k] = (rank_key[0], np.concatenate([xy, yw[..., None]], -1), tg, rank_key, has_nd)
        self.n_navsim_dac = sum(1 for e in self.by.values() if e[4])
        self.n_lane = self.n_lane_stale = self.n_lane_superseded = 0
        self.lane_keep: dict = {}
        if lane_labels:
            self._apply_lane_labels(lane_labels, n_prop)
        self.n_pdm = self.n_pdm_stale = self.n_pdm_superseded = 0
        self.pdm_keys: set = set()
        if pdm_labels:
            self._apply_pdm_labels(pdm_labels, n_prop)
        # PREREG_P2: with pdm_only the bank serves ONLY sets that carry the paper's PDM targets, so no set mixes label
        # sources; a training sample without one keeps its trajectory loss and gets no scorer loss (cand_m = 0).
        self.n_dropped_non_pdm = 0
        if pdm_only:
            if not pdm_labels:
                raise ValueError("pdm_only needs pdm_labels")
            keep = {k: v for k, v in self.by.items() if k in self.pdm_keys}
            self.n_dropped_non_pdm = len(self.by) - len(keep)
            self.by = keep
            self.n_navsim_dac = sum(1 for e in self.by.values() if e[4])
        self.n_tlane = self.n_tlane_stale = 0
        self.teacher_lane: dict = {}
        # 6 columns (the six components) unless a 7th, the teacher lane label, is loaded: then EVERY set serves 7, the
        # 7th = the soft lane target or -1 (no label -> masked by the loss). The default path stays exactly [M, 6].
        self.n_cols = 6
        if teacher_lane_labels:
            self._apply_teacher_lane(teacher_lane_labels, n_prop)
            self.n_cols = 7

    PDM_ORDER = ("nc", "dac", "ep", "ttc", "c", "ddc")      # = COMPONENTS order NC, DAC, EP, TTC, C, DDC

    def _apply_pdm_labels(self, path: str, n_prop: int):
        """SFT-4: the paper's scorer labels -- NAVSIM v1.1 PDM targets of the EXECUTED plans (onpolicy_relabel_pdm.py) --
        replace ALL SIX components of the set they were computed on (same key AND ckpt_step). DriveZero Sec. 3: "supervised
        by their corresponding PDM targets [17]" (RETRACTION_LOG R30). `pdm_keys` lists the sets that carry them, so a
        trainer can serve ONLY those (no set mixes label sources)."""
        import glob as _glob
        for fp in sorted(_glob.glob(os.path.join(path, "pdm_*.jsonl"))):
            with open(fp, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        d = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    k = tuple(d.get("key", ()))
                    if len(k) != 4:
                        continue
                    k = (k[0], k[1], int(k[2]), int(k[3]))
                    e = self.by.get(k)
                    if e is None:
                        continue
                    ok_len = all(len(d.get(c, ())) == n_prop for c in self.PDM_ORDER)
                    if int(d.get("ckpt_step", -1)) != int(e[0]) or not ok_len:
                        if ok_len and int(d.get("ckpt_step", -1)) < int(e[0]):
                            self.n_pdm_superseded += 1
                        else:
                            self.n_pdm_stale += 1
                        continue
                    e[2][:, :] = np.clip(np.stack([np.asarray(d[c], np.float32) for c in self.PDM_ORDER], -1), 0.0, 1.0)
                    self.pdm_keys.add(k)
                    self.n_pdm += 1

    LANE_D0, LANE_D1 = 0.5, 2.0     # teacher centre-line distance (m): <= D0 -> 1.0, >= D1 -> 0.0, linear between

    def _apply_teacher_lane(self, path: str, n_prop: int):
        """SFT-4's 7th label: the TEACHER SIMULATOR's own centre-line distance (center_line.CenterLine.info, max over the
        horizon; onpolicy_relabel_teacher_lane.py), MEASURED to rank NAVSIM-clean plans above violating ones at within-set
        AUC 0.904 (oncoming) / 0.856 (lane keeping) on the 3,137 held-out sets. Mapped to a soft target
        clip(1 - (d - LANE_D0) / (LANE_D1 - LANE_D0), 0, 1). Kept per set in `teacher_lane` (absent = masked)."""
        import glob as _glob
        for fp in sorted(_glob.glob(os.path.join(path, "teacher_lane_r*.jsonl"))):
            with open(fp, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        d = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    k = tuple(d.get("key", ()))
                    if len(k) != 4:
                        continue
                    k = (k[0], k[1], int(k[2]), int(k[3]))
                    e = self.by.get(k)
                    props = d.get("props") or []
                    if e is None:
                        continue
                    if int(d.get("ckpt_step", -1)) != int(e[0]) or len(props) != n_prop:
                        self.n_tlane_stale += 1
                        continue
                    dist = np.asarray([np.nan if p.get("center_line.CenterLine.info") is None
                                       else float(p["center_line.CenterLine.info"]) for p in props], np.float32)
                    if not np.isfinite(dist).all():
                        self.n_tlane_stale += 1
                        continue
                    self.teacher_lane[k] = np.clip(1.0 - (dist - self.LANE_D0) / (self.LANE_D1 - self.LANE_D0), 0.0, 1.0)
                    self.n_tlane += 1

    def _apply_lane_labels(self, path: str, n_prop: int):
        """SFT-2 (LANE-1 follow-on): side files from onpolicy_relabel_lane.py. A label replaces the DDC component ONLY
        for the set it was computed on -- same (log, token, step, rank) AND the same ckpt_step, i.e. the same proposals;
        any other match is counted as stale and ignored. DDC becomes NAVSIM's own verdict (1.0 / 0.5 / 0.0; validated
        100.00 % on 13,000 navtest trajectories) instead of DriveRL's wrong-way category. `lane_keep` is kept beside it."""
        import glob as _glob
        for fp in sorted(_glob.glob(os.path.join(path, "lane_*.jsonl"))):
            with open(fp, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        d = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    k = tuple(d.get("key", ()))
                    if len(k) != 4:
                        continue
                    k = (k[0], k[1], int(k[2]), int(k[3]))
                    e = self.by.get(k)
                    if e is None:
                        continue
                    if int(d.get("ckpt_step", -1)) != int(e[0]) or len(d.get("navsim_ddc", ())) != n_prop:
                        # a label of an OLDER checkpoint's proposals for this key is expected (the bank keeps the newest
                        # set); anything else does not belong to the set the bank serves
                        if len(d.get("navsim_ddc", ())) == n_prop and int(d.get("ckpt_step", -1)) < int(e[0]):
                            self.n_lane_superseded += 1
                        else:
                            self.n_lane_stale += 1
                        continue
                    e[2][:, 5] = np.clip(np.asarray(d["navsim_ddc"], np.float32), 0.0, 1.0)
                    self.lane_keep[k] = np.asarray(d.get("lane_keep", [0.0] * n_prop), np.float32)
                    self.n_lane += 1

    def get(self, log_name: str, token: str, step: int, rank: int = 0):
        k = (log_name, token, int(step), int(rank))
        e = self.by.get(k)
        if e is None:
            return None
        if self.n_cols == 7:
            lane = self.teacher_lane.get(k)
            col = lane if lane is not None else np.full(e[2].shape[0], -1.0, np.float32)
            return e[1], np.concatenate([e[2], col[:, None].astype(np.float32)], -1), e[0]
        return e[1], e[2], e[0]


def _pdm_aggregate(p):
    """planner.py `aggregate` on [..., 6] probabilities OR labels (component order NC, DAC, EP, TTC,
    C, DDC = ScorerBank.COMPONENTS): NC x DAC x DDC x (5 EP + 5 TTC + 4 C) / 14."""
    return p[..., 0] * p[..., 1] * p[..., 5] * (5.0 * p[..., 2] + 5.0 * p[..., 3] + 4.0 * p[..., 4]) / 14.0


def onpolicy_cov_norm(ds, op_bank, n_prop: int) -> float:
    """Mean labelled trajectories per SAMPLE over the dataset actually served (the fixed mode's
    `cov_norm`, same role: a constant denominator so --accum equals one large batch). Counted over
    the dataset's own rows, so a set whose sample is not in this epoch's bank adds nothing."""
    if not len(ds):
        return 1.0
    n = sum(1 for r in ds.rows if (r.get("log_name", ""), r.get("token", ""), int(r.get("step", 0)),
                                   int(r.get("rank", 0))) in op_bank.by)
    return max(n * n_prop / float(len(ds)), 1e-3)


def _open_aux_store(path: str, shuffle_seed):
    """P7.1: the head's label source. The store's OWN manifest pin is the integrity anchor (AuxLabelSource then checks: schema, raster spec, files-map hash == store_sha256, every shard's bytes
    against the manifest on read, the manifest's navtest-leak fields). Which store a LAUNCH may use is the gate's job: G-DVB compares the `aux` event's store_sha256 / key count with the
    profile's registered pins (refe_p7: the P7 TRAINING store, without the reserve), so a self-consistent store that is NOT the registered one is a launch blocker, never a silent success."""
    try:
        man = json.loads((Path(path) / "manifest.json").read_text(encoding="utf-8"))
        return AUX.AuxLabelSource(path, pinned_sha256=man.get("store_sha256"), pinned_keys=(man.get("counts") or {}).get("stored_keys"),
                                  shuffle_seed=shuffle_seed, max_logs=None)
    except (OSError, ValueError, AUX.StoreRefused) as e:
        raise SystemExit(f"TargetBank: --aux-drv-labels {path} is refused: {e}")


class TargetBank(Dataset):
    def __init__(self, target_dir: str, images_root: str | None, cfg: REFeConfig,
                 synthetic: bool = False, limit: int | None = None, spread: bool = False, scorer=None,
                 max_missing_frac: float = 0.001, calib: str | None = None,
                 sizes: dict | None = None, onpolicy=None, online: bool = False,
                 field_labels: str | None = None, field_shuffle_seed: int | None = None,
                 aux_labels: str | None = None, aux_shuffle_seed: int | None = None,
                 ego_yaw_table: str | None = None, traj_label_table: str | None = None):
        self.scorer = scorer
        # P6 / D1: the ONLINE labeller labels the model's own proposals, so each item also returns its row index (the trainer needs the row's
        # (log_name, token, rank, aug) to find the metric-cache parts). Off => the tuple is the unchanged nine elements.
        self.online = bool(online)
        # L_field (eval/PREREG_AUX_FIELD_LOSS_DRAFT.md): the stored ground-truth SDF per sample, read by aux_drivable_head.AuxLabelSource -- the ONE store reader (pinned
        # sha256 + key count, manifest/shard checks). `field_labels=None` (the default) => self.field is None and the item tuple is EXACTLY what it was without this
        # feature; otherwise the item carries two more elements, (sdf int8 [160, 128], valid bool), always the LAST TWO. The key is (log_name, token) ONLY: goal twins share a frame.
        self.field = None
        self.field_cov = None
        if field_labels:
            try:
                self.field = AUX.AuxLabelSource(field_labels, pinned_sha256=AUX.PINNED_STORE_SHA256, pinned_keys=AUX.PINNED_STORE_KEYS,
                                                shuffle_seed=field_shuffle_seed, max_logs=None)
                if field_shuffle_seed is not None:
                    self.field.key_map()                     # the derangement is built once, HERE, and travels to the workers with the dataset
            except AUX.StoreRefused as e:
                raise SystemExit(f"TargetBank: --field-labels {field_labels} is refused: {e}")
        # P7.1 (SPEC_P7 section 1): the SAME (sdf int8 [160, 128], valid bool) tail for the TRAINING-ONLY drivable-area head, read by the ONE store reader. `aux_labels=None` (the default)
        # => self.aux is None and the item tuple is EXACTLY what it was without the head; otherwise two more elements, ALWAYS THE LAST TWO (after L_field's pair when both are on).
        # The key is (log_name, token) ONLY: goal twins share a frame. The source is built from the store's OWN manifest pin (integrity: files map == store_sha256, every shard re-hashed
        # on read, the manifest's navtest-leak fields); WHICH store this run may train on is the launch gate's pin (G-DVB `aux_drv_labels`: the profile's registered sha256 / key count).
        self.aux = None
        self.aux_cov = None
        if aux_labels:
            self.aux = _open_aux_store(aux_labels, aux_shuffle_seed)
            if aux_shuffle_seed is not None:
                self.aux.key_map()
        # ⭐ on-policy mode (PI decision B): the paper's supervision REPLACES the fixed candidates
        self.onpolicy = onpolicy
        self.rows = []
        loaded = sorted(Path(target_dir).glob("targets_rank*.jsonl"))
        if sizes is not None:                   # --grow: exactly the epoch snapshot's files + bytes
            loaded = [p for p in loaded if "t:" + p.name in sizes]
        for p in loaded:
            if sizes is not None:
                self.rows += [json.loads(l) for l in read_upto(p, sizes["t:" + p.name])]
                continue
            with open(p, encoding="utf-8") as f:
                self.rows += [json.loads(l) for l in f]
        # ⛔⛔ A TARGET FILE LEFT IN THE DIRECTORY BUT NOT LOADED IS A SILENTLY DROPPED ARM.
        # MEASURED 2026-09-23: the diversity search writes `targets_aug.jsonl`, which the glob above
        # never matched -- so the goal augmentation (the lever the paper credits with +0.80 PDMS)
        # would have been dropped while training ran clean on rank 0 alone. Refuse instead.
        # against the FULL rank glob, not `loaded`: under --grow a rank file that appeared after the
        # snapshot is simply not in this epoch -- it is not a stray
        stray = sorted(set(Path(target_dir).glob("targets_*.jsonl"))
                       - set(Path(target_dir).glob("targets_rank*.jsonl")))
        if stray:
            raise SystemExit(f"TargetBank: {[s.name for s in stray]} sit in {target_dir} but do not "
                             f"match targets_rank*.jsonl and would be SILENTLY DROPPED. Rename them "
                             f"(augmented rows carry rank 1 -> targets_rank1.jsonl).")
        by_rank = {}
        for r in self.rows:
            by_rank[int(r.get("rank", 0))] = by_rank.get(int(r.get("rank", 0)), 0) + 1
        print(f"  targets: {len(self.rows):,} rows from {[p.name for p in loaded]}  "
              f"per rank {dict(sorted(by_rank.items()))}")
        if limit:
            # MEASURED 2026-09-20: taking the FIRST `limit` rows takes CONSECUTIVE frames of ONE
            # scenario, 0.1 s apart. Their pairwise L2 is 7.40 against 294.29 for independent noise
            # -- 39.8x closer -- so a synthetic arm gets a perfect per-index lookup key while the
            # real arm must map near-identical inputs to targets differing by ~1 m. That makes the
            # overfit control WEAK and makes real-vs-synthetic look like an image-difficulty result
            # when it is a sampling artifact. `spread` takes an even stride across the whole bank,
            # which draws from different scenarios.
            if spread and len(self.rows) > limit:
                step = len(self.rows) // limit
                self.rows = [self.rows[i * step] for i in range(limit)]
            else:
                self.rows = self.rows[:limit]
        self.images_root = images_root
        self.store = FrameStore(images_root)
        self.cfg = cfg
        self.synthetic = synthetic
        self.n_dropped_missing = 0
        # ⛔⛔ RESOLVE EVERY FRAME AT LOAD, NOT ON DAY 20 (R21). `__getitem__` raises on a missing
        # frame; under a supervisor that is a CRASH LOOP -- the resume restores the exact data
        # position, re-reads the same tuple and dies again until the restart budget is gone. A few
        # absent frames are dropped HERE, counted and named; a fraction above `max_missing_frac`
        # is a broken JOIN (wrong root, wrong split, wrong layout) and is refused outright.
        if not synthetic and images_root and self.rows:
            t_res = time.time()
            keep, miss, first_bad = [], [], []
            for r in self.rows:
                refs = r["image"] if isinstance(r["image"], list) else [r["image"]]
                bad = [x for x in refs if not self.store.resolvable(x, r.get("log_name", ""))]
                (miss if bad else keep).append(r)
                if bad and len(first_bad) < 3:
                    first_bad.append(bad[0])          # name the frame that is ACTUALLY missing
            frac = len(miss) / max(len(self.rows), 1)
            print(f"  images: {len(keep):,}/{len(self.rows):,} tuples resolve ALL cameras under "
                  f"{images_root}  ({len(self.store.index()):,} loose frames indexed, "
                  f"{len(self.store.container_set())} containers, {time.time() - t_res:.1f} s)")
            if miss:
                ex = first_bad
                if frac > max_missing_frac:
                    raise SystemExit(
                        f"TargetBank: {len(miss):,} of {len(self.rows):,} tuples "
                        f"({100 * frac:.2f} %) name a frame that does not resolve under "
                        f"{images_root} -- above the {100 * max_missing_frac:.2f} % limit, so this "
                        f"is a broken JOIN, not a few absent frames. e.g. {ex}")
                print(f"  *** DROPPED {len(miss):,} tuples ({100 * frac:.3f} %) with an "
                      f"unresolvable frame, e.g. {ex}")
                self.n_dropped_missing = len(miss)
                self.rows = keep
        # ⭐ PER-SAMPLE CALIBRATION (R22). PETR -- the paper's cited 3D position embedding --
        # builds each sample's embedding from ITS OWN rig. Without a table every tuple is lifted
        # with the one baked vehicle (MEASURED exact on 3.2 % of local logs, rotation off by up to
        # 2.67 deg). A tuple whose log has no calibration is dropped and counted like a missing
        # frame -- never silently given the baked rig, which would re-open the defect per tuple.
        self.calib_table = None
        self.n_dropped_calib = 0
        if calib and self.rows:
            import calib_table as CT
            self.calib_table = CT.load(calib)
            keep, miss = [], []
            for r in self.rows:
                v = CT.vectors(self.calib_table, r.get("log_name", ""), cfg.cameras)
                if v is None:
                    miss.append(r)
                else:
                    r["_calib"] = v
                    keep.append(r)
            frac = len(miss) / max(len(self.rows), 1)
            n_rigs = len({tuple(map(tuple, r["_calib"])) for r in keep})
            print(f"  calib: {len(keep):,}/{len(self.rows):,} tuples carry their own rig "
                  f"({n_rigs} distinct rigs) <- {calib}")
            if miss:
                ex = sorted({m.get("log_name") for m in miss})[:3]
                if frac > max_missing_frac:
                    raise SystemExit(f"TargetBank: {len(miss):,} tuples ({100 * frac:.2f} %) have no "
                                     f"calibration for their log in {calib} -- above the "
                                     f"{100 * max_missing_frac:.2f} % limit. e.g. {ex}")
                print(f"  *** DROPPED {len(miss):,} tuples with no calibration, e.g. {ex}")
                self.n_dropped_calib = len(miss)
                self.rows = keep
        if not self.rows:
            raise RuntimeError(f"no tuples under {target_dir}")
        # ⭐ SCENES (R24). Rows sharing (log_name, token, step) are ONE scene: its rank-0 target plus
        # any goal-augmented twins. The key is the scorer bank's key without the rank, so it means
        # the same frame for the navtrain source (token = frame, step = 0) and the older val14 one
        # (token = scenario, step = frame). Members are ordered by rank: member 0 = logged intent.
        idx: dict = {}
        for i, r in enumerate(self.rows):
            idx.setdefault((r.get("log_name", ""), r.get("token", ""), int(r.get("step", 0))),
                           []).append(i)
        self.scene_groups = [sorted(v, key=lambda i: int(self.rows[i].get("rank", 0)))
                             for v in idx.values()]
        # ⛔ a scene holding the SAME rank twice is a duplicated row (an overlapping shard merge),
        # not a twin -- it would silently double one target's weight. The pipeline guarantees
        # uniqueness (resume keys on the same tuple), so a violation is a defect: refuse it.
        dup = [g for g in self.scene_groups
               if len({int(self.rows[i].get("rank", 0)) for i in g}) != len(g)]
        if dup:
            r0 = self.rows[dup[0][0]]
            raise SystemExit(f"TargetBank: {len(dup):,} scenes hold the same rank twice (duplicated "
                             f"rows), e.g. {r0.get('log_name')} {r0.get('token')} step "
                             f"{r0.get('step')}. Fix the bank merge; do not train on it.")
        sizes: dict = {}
        for g in self.scene_groups:
            sizes[len(g)] = sizes.get(len(g), 0) + 1
        print(f"  scenes: {len(self.scene_groups):,} over {len(self.rows):,} tuples  (rows per "
              f"scene: {', '.join(f'{k} x {v:,}' for k, v in sorted(sizes.items()))})")
        # P6 / D6: where each row's navigation command comes from (NAVSIM's own, carried in the row, or the goal rule). Reported, never silent.
        self.cmd_sources = None
        if cfg.nav_mode == "command":
            self.cmd_sources = {}
            for r in self.rows:
                k = NC.command_source(r)
                self.cmd_sources[k] = self.cmd_sources.get(k, 0) + 1
            print(f"  NAV COMMAND (P6): sources {self.cmd_sources}  (row = NAVSIM driving_command carried by the bank; goal_rule = nav_command.goal_to_command, "
                  f"MEASURED 0.90 agreement with NAVSIM on navtest -- below SPEC_P6 D6's 95 % bar)")
        # ⭐ WP YAW (PLAN: TanitAD-artifacts/yawrate_wp/PLAN.md). Ego slot 4 (yaw_rate) is 0.0 in EVERY banked row (D-REFE-DEADSLOTS-1): nuPlan's DB loader never reads ego_pose.angular_rate_z.
        # `ego_yaw_table=None` (the default) is the unchanged loader. With a table, __getitem__ replaces slot 4 by the table's value for the ROW'S TOKEN; slot 5 (steering) stays whatever the
        # bank has. ⛔ EVERYTHING that could make the override silent is refused HERE, at construction, over the FINAL rows (after every drop above) -- not three hours in, in a worker:
        # a row whose token the table lacks, a bank whose slot 4 is already non-zero (two sources for one slot), a model with no slot 4.
        self.ego_yaw = None
        self.ego_yaw_sha256 = None
        self.ego_yaw_cov = None
        if ego_yaw_table:
            try:
                self.ego_yaw, ymeta, self.ego_yaw_sha256 = EYT.load(ego_yaw_table)
            except (OSError, ValueError, EYT.TableRefused) as e:
                raise SystemExit(f"TargetBank: --ego-yaw-table {ego_yaw_table} is refused: {e}")
            if cfg.ego_dim <= EYT.EGO_YAW_SLOT:
                raise SystemExit(f"TargetBank: --ego-yaw-table needs a model with an ego slot {EYT.EGO_YAW_SLOT} (yaw_rate); this config has ego_dim {cfg.ego_dim}.")
            lacking = [r for r in self.rows if r.get("token", "") not in self.ego_yaw]
            if lacking:
                ex = [(r.get("log_name", "?"), r.get("token", "?")) for r in lacking[:3]]
                raise SystemExit(f"TargetBank: --ego-yaw-table covers {len(self.rows) - len(lacking):,}/{len(self.rows):,} rows; {len(lacking):,} rows' tokens are NOT in the table "
                                 f"({ego_yaw_table}, sha256 {self.ego_yaw_sha256[:12]}), e.g. {ex}. REFUSED: a missing token would train on a yaw of 0.0 for that row without saying so. "
                                 f"Rebuild the table over the bank's own logs (ego_yaw_table.py build / check-bank).")
            nz = [r for r in self.rows if len(r.get("ego") or ()) > EYT.EGO_YAW_SLOT and float(r["ego"][EYT.EGO_YAW_SLOT]) != 0.0]
            if nz:
                raise SystemExit(f"TargetBank: --ego-yaw-table, but {len(nz):,} bank rows ALREADY carry a non-zero ego[{EYT.EGO_YAW_SLOT}] (e.g. {nz[0].get('log_name')} {nz[0].get('token')}): "
                                 f"two sources for one slot. REFUSED -- drop the flag (the bank has its own yaw rate) or rebuild the bank.")
            self.ego_yaw_cov = {"rows": len(self.rows), "covered": len(self.rows), "table_tokens": len(self.ego_yaw)}
            print(f"  EGO YAW (WP YAW): ego[{EYT.EGO_YAW_SLOT}] <- {EYT.YAW_SCALE:g} x {EYT.FIELD} for {len(self.rows):,}/{len(self.rows):,} rows ({len(self.ego_yaw):,} table tokens, "
                  f"sha256 {self.ego_yaw_sha256[:12]}, {ymeta.get('units', '?')})  <- {ego_yaw_table}")
        # ⭐ P5-C (scorer_gym_20261107/p5c/P5C_READINESS.md section 3): train on the tracker-aware Tc20s LABEL instead of each row's raw `traj`.  `traj_label_table=None` (the default) is the unchanged
        # loader.  With a table, __getitem__ replaces slot 3 (the WTA target) by the table's label for the ROW (log, token, rank), proven to be computed from THIS row's own traj by its sha256.  A row
        # the table does not carry KEEPS its raw traj (coverage is printed and kept in `traj_label_cov`; the table may declare a required coverage and then REFUSES below it); a row whose
        # (log, token, rank) IS in the table under a different traj sha256, and a label that is not [T, 3] / finite / on the raw row's yaw branch, REFUSE here, at construction, over the FINAL rows.
        self.traj_label = None
        self.traj_label_sha256 = None
        self.traj_label_cov = None
        if traj_label_table:
            try:
                tlt = TLT.load(traj_label_table)
                res = TLT.apply_to_rows(tlt, self.rows)
            except (OSError, ValueError, TLT.TableRefused) as e:
                raise SystemExit(f"TargetBank: --traj-label-table {traj_label_table} is refused: {e}")
            self.traj_label = res["labels"]              # {row index: label [T][3]}; absent index = keeps the raw traj
            self.traj_label_sha256 = tlt.sha256
            self.traj_label_cov = res["coverage"]
            c_ = self.traj_label_cov
            print(f"  TRAJ LABEL (P5-C): slot 3 <- table label for {c_['covered']:,}/{c_['rows']:,} rows ({100.0 * c_['coverage']:.3f} %), {c_['kept_raw']:,} keep the raw traj, "
                  f"{c_['differs_from_raw']:,} labels differ from raw {c_['differs_by_rank']} (rank_policy {c_['rank_policy']}; {tlt.meta.get('label_name') or '?'}; {c_['table_keys']:,} table keys, table sha256 {self.traj_label_sha256})  <- {traj_label_table}")
        if self.field is not None:
            # coverage of the FINAL rows (after every drop above) by the label store, keyed by (log_name, token): a row the store lacks reads zeros + valid False = exactly 0 loss
            have = set(self.field.all_keys())
            n_lab = sum(1 for r in self.rows if (r.get("log_name", ""), r.get("token", "")) in have)
            self.field_cov = {"rows": len(self.rows), "labelled": n_lab, "store_keys": len(have)}
            print(f"  L_field labels: {n_lab:,}/{len(self.rows):,} rows ({100.0 * n_lab / max(len(self.rows), 1):.3f} %) have a stored SDF  <- {field_labels}  "
                  f"(store_sha256 {self.field.manifest['store_sha256'][:12]}, {len(have):,} keys"
                  + (f"; LABEL-SHUFFLED CONTROL, derangement seed {field_shuffle_seed}" if field_shuffle_seed is not None else "") + ")")
        if self.aux is not None:
            # coverage of the FINAL rows (after every drop above) by the head's label store, keyed by (log_name, token): a row the store lacks reads zeros + valid False = exactly 0 loss
            have = set(self.aux.all_keys())
            n_lab = sum(1 for r in self.rows if (r.get("log_name", ""), r.get("token", "")) in have)
            self.aux_cov = {"rows": len(self.rows), "labelled": n_lab, "store_keys": len(have)}
            print(f"  P7.1 aux-head labels: {n_lab:,}/{len(self.rows):,} rows ({100.0 * n_lab / max(len(self.rows), 1):.3f} %) have a stored SDF  <- {aux_labels}  "
                  f"(store_sha256 {self.aux.manifest['store_sha256'][:12]}, {len(have):,} keys"
                  + (f"; LABEL-SHUFFLED CONTROL, derangement seed {aux_shuffle_seed}" if aux_shuffle_seed is not None else "") + ")")

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]
        c = self.cfg
        if self.synthetic:
            g = torch.Generator().manual_seed(i)          # deterministic per index
            img = (torch.randn(c.n_cameras, 3, c.img_h, c.img_w, generator=g)
                   if c.n_cameras > 1 else torch.randn(3, c.img_h, c.img_w, generator=g))
        else:
            import cv2
            # ⭐ FOUR CAMERAS. A tuple's "image" is a LIST of paths, one per camera, in the order
            # `build_targets.CAMERAS` records. A legacy single-path row still loads, and the
            # camera-count guard in REFe.forward is what stops a 1-camera tuple being trained
            # through a 4-camera model by accident.
            paths = r["image"] if isinstance(r["image"], list) else [r["image"]]
            frames = []
            for pth in paths:
                blob = self.store.read(pth, r.get("log_name", ""))
                if blob is None:
                    raise FileNotFoundError(f"{pth} (log {r.get('log_name')})")
                im = cv2.imdecode(np.frombuffer(blob, np.uint8), cv2.IMREAD_COLOR)
                if im is None:
                    raise ValueError(f"undecodable frame: {pth}")
                im = cv2.resize(im, (c.img_w, c.img_h))[:, :, ::-1].astype(np.float32) / 255.0
                frames.append(torch.from_numpy(np.ascontiguousarray(im.transpose(2, 0, 1))))
            img = torch.stack(frames) if len(frames) > 1 else frames[0]
        if self.onpolicy is not None:
            # ⭐ ON-POLICY (PI decision B): the sample's labelled SET -- all n_proposals trajectories
            # [M, T, 3] (x, y, yaw) with their six targets -- or an all-zero mask when this sample has
            # no complete set yet. The fixed candidates are NOT used in this mode (the paper's
            # version). Same tuple layout as the fixed path; the loop branches on the mode.
            M = c.n_proposals
            ot = torch.zeros(M, c.horizon_steps, 3, dtype=torch.float32)
            og = torch.zeros(M, getattr(self.onpolicy, "n_cols", 6), dtype=torch.float32)
            om = torch.zeros(M, dtype=torch.float32)
            oi = torch.full((M,), -1, dtype=torch.long)
            got = self.onpolicy.get(r.get("log_name", ""), r.get("token", ""), r.get("step", -1),
                                    int(r.get("rank", 0)))
            if got is not None:
                tr3, tg, cstep = got
                ot.copy_(torch.from_numpy(tr3))
                og.copy_(torch.from_numpy(tg))
                om.fill_(1.0)
                oi.fill_(int(cstep))              # which checkpoint's proposals: the lag, per sample
            ct, cg, cm, ci = ot, og, om, oi
        else:
            ct = cg = cm = ci = None
        # the per-frame candidate set, PADDED to KMAX with a mask. A frame with no scorer targets
        # returns an all-zero mask and contributes NOTHING to the scorer loss -- which is why the
        # loop prints coverage: a silently empty bank would just look like a small loss.
        if self.onpolicy is None:
            ct = torch.zeros(KMAX, c.horizon_steps, 2, dtype=torch.float32)
            cg = torch.zeros(KMAX, 6, dtype=torch.float32)
            cm = torch.zeros(KMAX, dtype=torch.float32)
            ci = torch.full((KMAX,), -1, dtype=torch.long)
            got = (self.scorer.get(r.get("log_name", ""), r.get("token", ""), r.get("step", -1),
                                   int(r.get("rank", 0)))
                   if self.scorer else None)
            if got is not None:
                trs, tgs, nms = got
                for j, (tr, tg, nm) in enumerate(zip(trs, tgs, nms)):
                    if j >= KMAX:
                        break
                    ci[j] = CAND_INDEX.get(nm, -1)
                    a = torch.tensor(tr, dtype=torch.float32)[:c.horizon_steps, :2]
                    ct[j, :a.shape[0]] = a
                    cg[j] = torch.tensor(tg, dtype=torch.float32)
                    cm[j] = 1.0
        # ⛔ REFUSE A BANK WHOSE EGO WIDTH IS NOT THE MODEL'S, AND SAY WHICH BANK.
        # `goal` two lines below has always been SLICED to the config, so a goal mismatch passed
        # silently; `ego` was neither sliced nor checked, so an `ego_dim` move showed up as
        # `mat1 and mat2 shapes cannot be multiplied (2x44 and 45x256)` -- a matmul error 3 frames
        # deep that names neither the bank nor the field. ⚠️ Deliberately NOT padded or truncated:
        # a 7-D kinematics vector and an 8-D one with a trailing pad are different corpora, and
        # quietly reshaping one into the other is how a model trains on a column of zeros.
        ego_t = torch.tensor(r["ego"], dtype=torch.float32)
        if ego_t.numel() != c.ego_dim:
            raise RuntimeError(
                f"target bank has {ego_t.numel()}-D ego but the model is configured for "
                f"{c.ego_dim}-D (log {r.get('log_name','?')} step {r.get('step','?')}). "
                f"Rebuild the bank with build_targets.py, or set REFeConfig.ego_dim to match. "
                f"These two must move together -- see diag_consumer_conformance.py.")
        if self.ego_yaw is not None:
            # WP YAW: slot 4 <- YAW_SCALE (10.0, MM 2026-11-06: raw ego inputs are ~10 / ~1 and |w| <= 0.35 rad/s) x the DB's measured yaw rate for THIS row's token (rad/s, CCW+). Slot 5 is NOT touched. The constructor already proved every row's token is in the table; this
            # is the backstop for a row that arrives by another path (--grow's rebuilt banks pass through the same constructor, so it cannot, but a lookup that cannot fail silently is cheap).
            tok = r.get("token", "")
            if tok not in self.ego_yaw:
                raise RuntimeError(f"--ego-yaw-table has no entry for token {tok!r} (log {r.get('log_name', '?')}): REFUSED rather than train this row on a yaw of 0.0.")
            ego_t[EYT.EGO_YAW_SLOT] = EYT.YAW_SCALE * self.ego_yaw[tok]
        # float64 on purpose: the rig is a cache KEY in the model, and float32 would round every
        # vehicle's numbers differently from the table's -- same geometry, different key
        cal = (torch.tensor(r["_calib"], dtype=torch.float64) if "_calib" in r
               else torch.zeros(0, dtype=torch.float64))
        if c.nav_mode == "command":
            gl = torch.tensor(NC.onehot(NC.command_of_row(r)), dtype=torch.float32)       # P6 / D6: the one-hot command rides in the `goal` slot
        else:
            gl = torch.tensor(r["goal"], dtype=torch.float32)[:2 * c.n_goal_points]
        # P5-C: the WTA target.  Without --traj-label-table (self.traj_label is None) this is `torch.tensor(r["traj"])`, the unchanged expression; with it, a covered row's table label.
        tgt_t = torch.tensor(self.traj_label[i] if (self.traj_label is not None and i in self.traj_label) else r["traj"], dtype=torch.float32)
        item = (img,
                ego_t,
                gl,
                tgt_t,
                ct, cg, cm, ci, cal)
        item = item + (torch.tensor(i, dtype=torch.long),) if self.online else item
        if self.field is not None:
            # L_field: (sdf int8 [160, 128], valid bool) as the LAST TWO elements, after the optional row index. A key with no stored label reads zeros and valid False.
            key = (r.get("log_name", ""), r.get("token", ""))
            if self.field.shuffle_seed is not None and key not in self.field.key_map():
                lab, vld = torch.zeros(1, 160, 128, dtype=torch.int8), torch.zeros(1, dtype=torch.bool)      # the control's derangement covers the STORE's keys; a frame outside it has no label
            else:
                lab, vld = self.field.labels([key])
            item = item + (lab[0], vld[0])
        if self.aux is not None:
            # P7.1: (sdf int8 [160, 128], valid bool) as the LAST TWO elements. A key with no stored label reads zeros and valid False (= exactly 0 loss and 0 gradient for that frame).
            akey = (r.get("log_name", ""), r.get("token", ""))
            if self.aux.shuffle_seed is not None and akey not in self.aux.key_map():
                alab, avld = torch.zeros(1, 160, 128, dtype=torch.int8), torch.zeros(1, dtype=torch.bool)
            else:
                alab, avld = self.aux.labels([akey])
            item = item + (alab[0], avld[0])
        return item


class EpochSampler(torch.utils.data.Sampler):
    """A seeded permutation PER EPOCH that can start mid-epoch.

    ⛔ The DataLoader's own `shuffle=True` draws its permutation from the GLOBAL torch RNG at the
    start of each epoch, and a resumed process cannot rewind to "sample 41,216 of epoch 7" -- it
    would replay the epoch from its start, training twice on what it had already seen and never
    on the rest. Seeding by (seed, epoch) makes every epoch's order a pure function of two
    integers, so a checkpoint only has to record (epoch, position).
    """

    def __init__(self, n: int, seed: int, shuffle: bool = True):
        self.n, self.seed, self.shuffle = int(n), int(seed), bool(shuffle)
        self.epoch, self.start = 0, 0

    def set_epoch(self, epoch: int, start: int = 0) -> None:
        self.epoch, self.start = int(epoch), int(start)

    def order(self) -> list:
        if not self.shuffle:
            return list(range(self.n))
        g = torch.Generator()
        g.manual_seed(self.seed * 1_000_003 + self.epoch)
        return torch.randperm(self.n, generator=g).tolist()

    def __iter__(self):
        return iter(self.order()[self.start:])

    def __len__(self) -> int:
        return max(self.n - self.start, 0)


class SceneEpochSampler(torch.utils.data.Sampler):
    """ONE ROW PER SCENE PER EPOCH -- the paper's unit (PI decision 2026-09-23, R24).

    DriveZero counts its training data in SCENES ("100K navtrain + 237K SimScale scenes", Table
    A12) and trains "25 epochs". Our bank stores each goal-augmented target as an extra ROW beside
    its scene's rank-0 row (~1.71 rows per scene at tau 0.3), so an epoch over ROWS spends 1.71x
    the paper's budget -- ~64-69 A40-days instead of ~37-41 -- and visits scenes that have an
    augmented twin twice as often as the ~29 % that have none.

    Every epoch visits every scene exactly once, in a seeded order, using ONE of its rows: member
    `(epoch + offset[scene]) mod k`, with `offset` a seeded per-scene constant. Over E epochs each
    member of a k-row scene is therefore used floor/ceil(E/k) times (balanced WITHIN the scene),
    and inside any single epoch the members are MIXED across scenes -- ⛔ not "rank 0 on even
    epochs, rank 1 on odd", which would make whole epochs single-goal. Pure function of
    (seed, epoch), so a checkpoint's (epoch, position) still resumes exactly.
    """

    def __init__(self, groups: list, seed: int, shuffle: bool = True):
        self.groups = [list(g) for g in groups]
        self.n = len(self.groups)
        self.seed, self.shuffle = int(seed), bool(shuffle)
        self.epoch, self.start = 0, 0
        g0 = torch.Generator()
        g0.manual_seed(self.seed * 7_919 + 104_729)
        self.offset = torch.randint(0, 1 << 30, (max(self.n, 1),), generator=g0).tolist()

    def set_epoch(self, epoch: int, start: int = 0) -> None:
        self.epoch, self.start = int(epoch), int(start)

    def order(self) -> list:
        if self.shuffle:
            g = torch.Generator()
            g.manual_seed(self.seed * 1_000_003 + self.epoch)
            scenes = torch.randperm(self.n, generator=g).tolist()
        else:
            scenes = range(self.n)
        return [self.groups[q][(self.epoch + self.offset[q]) % len(self.groups[q])]
                for q in scenes]

    def __iter__(self):
        return iter(self.order()[self.start:])

    def __len__(self) -> int:
        return max(self.n - self.start, 0)


# Arguments that DEFINE a run. A resume that changes any of them is not a resume -- it is a new
# run wearing the old one's step counter -- so it is refused, not reconciled. Paths are recorded
# but not compared (a bank moved to another disk is the same bank); the bank's CONTENT is.
IDENTITY_ARGS = ("backbone", "synthetic", "n_cameras", "undistort", "detach_scorer_context",
                 "batch", "accum", "lr", "weight_decay", "cosine", "epochs", "steps", "score_w",
                 "seed", "spread", "overfit", "overfit_n", "epoch_unit", "amp", "tf32",
                 "fused_adam", "compile", "grow", "grow_scenes", "scorer_mode", "init_from", "pdm_labels",
                 "pdm_only", "yaw_wrap", "nav_mode", "labeller", "label_backend",
                 "w_field", "field_margin", "field_interp", "field_labels", "field_shuffle_seed") + AUX.AUX_IDENTITY_ARGS      # P7.1: a resume with a different head is refused
# ⭐ an identity key ADDED after runs began: an OLD checkpoint lacks it and must read as the value
# those runs actually used, or every pre-existing run would refuse its own resume
IDENTITY_DEFAULTS = {"scorer_mode": "fixed", "init_from": None, "pdm_labels": None, "pdm_only": False,
                     "yaw_wrap": "on", "nav_mode": "goal", "labeller": "bank", "label_backend": "pdm",
                     "w_field": 0.0, "field_margin": 0.25, "field_interp": "5hz", "field_labels": None, "field_shuffle_seed": None,
                     # P7.1: every pre-P7 checkpoint was trained WITHOUT the head, so it reads as head-off and still resumes under this trainer
                     "aux_drv": False, "w_aux_drv": 0.0, "aux_drv_tap": "visual", "aux_drv_depth": 2, "aux_drv_feed": "off", "aux_drv_labels": "", "aux_drv_shuffle_seed": None}


def warm_start(model, path: str) -> dict:
    """PREREG_P2: start from a TRAINED REFe instead of the paper's fresh heads. FULL format (what planner.py loads) is
    loaded STRICTLY; a PARTIAL snapshot through ckpt_io.load_partial (the trunk is already the published one). Returns
    what was loaded, for config.json."""
    sd = torch.load(path, map_location="cpu", weights_only=False)
    if isinstance(sd, dict) and (sd.get("format") == ckpt_io.FORMAT_PARTIAL or "model_partial" in sd):
        n = ckpt_io.load_partial(model, sd["model_partial"], (sd.get("meta") or {}).get("frozen_sha256"))
        fmt = ckpt_io.FORMAT_PARTIAL
    else:
        st = sd["model"] if isinstance(sd, dict) and "model" in sd else sd
        model.load_state_dict(st, strict=True)
        n, fmt = len(st), ckpt_io.FORMAT_FULL
    return {"path": path, "format": fmt, "tensors": n, "sha256": ckpt_io.sha256_file(path)}
# what a GROWING bank changes by design; each epoch's own snapshot is in the checkpoint instead
GROW_EXEMPT = ("n_tuples", "n_scenes", "per_rank", "targets_sha256", "scorer_sha256")


def _digest_files(paths) -> str:
    h = hashlib.sha256()
    for q in paths:
        h.update(os.path.basename(str(q)).encode("utf-8"))
        with open(q, "rb") as f:
            for b in iter(lambda: f.read(1 << 22), b""):
                h.update(b)
    return h.hexdigest()


def run_identity(a, ds, scorer_bank, frozen_sha256) -> dict:
    """What a resume must match: the defining arguments, the bank's content, and the trunk."""
    tfiles = sorted(Path(a.targets).glob("targets_rank*.jsonl"))
    per_rank: dict = {}
    for r in ds.rows:
        k = str(int(r.get("rank", 0)))
        per_rank[k] = per_rank.get(k, 0) + 1
    grow = bool(getattr(a, "grow", False))
    ident = {"args": {k: getattr(a, k, None) for k in IDENTITY_ARGS},
             "n_tuples": len(ds), "n_scenes": len(ds.scene_groups), "per_rank": per_rank,
             # not hashed under --grow: the files are still being appended to (GROW_EXEMPT)
             "targets_sha256": None if grow else _digest_files(tfiles),
             "scorer_sha256": (None if grow else
                               _digest_files(getattr(scorer_bank, "files", []) or [])),
             "calib_sha256": _digest_files([a.calib]) if a.calib else None,
             "frozen_sha256": frozen_sha256}
    if a.field_labels:
        # L_field: the label store's CONTENT (its manifest sha256), beside the path in `args` -- a key present ONLY on a field run, so every other run's identity is unchanged
        ident["field_store_sha256"] = ds.field.manifest["store_sha256"] if getattr(ds, "field", None) is not None else None
    if a.aux_drv_labels:
        # P7.1: the head's label store CONTENT, beside the path in `args` -- a key present ONLY on a head run, so every other run's identity is unchanged
        ident["aux_store_sha256"] = ds.aux.manifest["store_sha256"] if getattr(ds, "aux", None) is not None else None
    if getattr(a, "traj_label_table", None):
        # P5-C: the label table's CONTENT (sha256 of the file), never its path -- a key present ONLY on a P5-C run, so every other run's identity is unchanged. A resume under a different table is refused.
        ident["traj_label_sha256"] = getattr(ds, "traj_label_sha256", None)
    if getattr(a, "ego_yaw_table", None):
        # WP YAW: the yaw table's CONTENT (sha256 of the file), never its path -- a key present ONLY on a yaw run, so every other run's identity is unchanged. A resume under a different table is refused.
        ident["ego_yaw_sha256"] = getattr(ds, "ego_yaw_sha256", None)
        ident["ego_yaw_scale"] = EYT.YAW_SCALE
    return ident


def _identity_diff(old: dict, new: dict, declared=(), accepted: list | None = None) -> list:
    """Every way `new` differs from the checkpoint's identity. A key named in `declared` (--declare-
    change) is a DELIBERATE mid-run recipe change: it is moved to `accepted`, never silently dropped."""
    out = []
    changed_declared = set()
    for k in IDENTITY_ARGS:
        ov = old["args"].get(k, IDENTITY_DEFAULTS.get(k))
        if ov != new["args"].get(k):
            msg = f"--{k.replace('_', '-')}: {ov!r} -> {new['args'].get(k)!r}"
            if k in declared and accepted is not None:
                accepted.append(msg)
                changed_declared.add(k)
                continue
            out.append(msg)
    grow = bool(new["args"].get("grow")) and bool(old["args"].get("grow"))
    for k in ("n_tuples", "n_scenes", "per_rank", "targets_sha256", "scorer_sha256",
              "calib_sha256", "frozen_sha256", "field_store_sha256", "aux_store_sha256", "ego_yaw_sha256", "ego_yaw_scale"):
        if grow and k in GROW_EXEMPT:
            continue
        if old.get(k) != new.get(k):
            ov, nv = old.get(k), new.get(k)
            if isinstance(ov, str) and len(ov) == 64:
                ov, nv = ov[:12], (nv or "")[:12]
            # ⭐ the scorer bank's digest FOLLOWS a declared --scorer-mode change by definition: the
            # on-policy mode reads a different bank (MEASURED in diag_onpolicy_train: a non-grow resume
            # refused on scorer_sha256 while the declared mode change itself was accepted). It is
            # accepted AND named, never skipped silently; every other digest still refuses.
            if k == "scorer_sha256" and "scorer_mode" in changed_declared and accepted is not None:
                accepted.append(f"{k}: {ov!r} -> {nv!r} (follows the declared --scorer-mode change)")
                continue
            out.append(f"{k}: {ov!r} -> {nv!r}")
    return out


def _rng_state() -> dict:
    return {"torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
            "numpy": np.random.get_state(), "python": random.getstate()}


def _set_rng_state(st: dict) -> None:
    torch.set_rng_state(st["torch"])
    if st.get("cuda") is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(st["cuda"])
    np.random.set_state(st["numpy"])
    random.setstate(st["python"])


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _append_jsonl(path, row: dict) -> None:
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row) + "\n")


def run(a) -> int:
    dev = "cuda" if torch.cuda.is_available() and not a.cpu else "cpu"
    # ⛔⛔ A TRAINING RUN THAT SAVES NOTHING IS REFUSED. Until 2026-09-23 (R20) this trainer had no
    # checkpoint, no final model and no resume: the planned ~60-day ViT-L run would have ended with
    # its weights in process memory only, and any pod restart would have cost all of it. Controls
    # and smoke runs (<= 500 steps, or --overfit) may still run without a run directory.
    if a.resume and not a.out:
        print("  REFUSING: --resume needs --out (the run directory that holds ckpt_last.pt).")
        return 4
    if not a.out and not a.overfit and (a.epochs > 0 or a.steps > 500):
        print("  REFUSING TO TRAIN WITHOUT --out: this run would save NO checkpoint and NO model. "
              "Pass --out <run dir> (and --resume under a supervisor).")
        return 4
    # ⭐ SPEED FLAGS (2026-09-23, first REFe pod; PI: training must fit <= 15 days). MEASURED on the
    # A40, ViT-L, 4 cameras, the real step (refe/bench_speed.py): FP32 batch 4 1.282 s/sample, TF32
    # 1.007, bf16 autocast 0.366 -- 3.5x. ⚠️ Table A12 says "Training precision FP32": --amp bf16 is a
    # DECLARED DEPARTURE, recorded in config.json and in the resume identity, and validated for
    # numerics against FP32 (refe/diag_amp.py) before it is used for a run.
    if a.tf32:
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    if a.amp != "none" or a.tf32 or a.fused_adam or a.workers or a.compile:
        print(f"  SPEED: amp={a.amp} tf32={a.tf32} compile={a.compile} fused_adam={a.fused_adam} "
              f"workers={a.workers}"
              + ("   (DEPARTURE from the paper's FP32)" if a.amp != "none" or a.tf32 else ""))
    cfg = REFeConfig.for_backbone(a.backbone)
    online = (a.labeller == "online")
    if online and (a.grow or a.scorer_mode != "fixed" or a.onpolicy_targets or a.pdm_labels or a.pdm_only):
        print("  REFUSING: --labeller online replaces the banked/on-policy label sources; it cannot be combined with --grow, --scorer-mode onpolicy, "
              "--onpolicy-targets, --pdm-labels or --pdm-only.")
        return 4
    if online and a.label_backend == "pdm" and not a.metric_cache:
        print("  REFUSING: --labeller online with the pdm backend needs --metric-cache (the D9 parts directory, refe/build_metric_cache.py).")
        return 4
    # L_field (eval/PREREG_AUX_FIELD_LOSS_DRAFT.md). --w-field defaults to 0.0 and a term that is OFF is not computed at all (the trainer is then bit-identical to one without
    # the feature); an arm that means it NAMES it. A weight with no label source, or a shuffle seed with no labels, is a lever that would silently do nothing: refused.
    if not (0.0 <= a.w_field < float("inf")):
        print(f"  REFUSING: --w-field {a.w_field} must be a finite number >= 0."); return 4
    if not (-float("inf") < a.field_margin < float("inf")):
        print(f"  REFUSING: --field-margin {a.field_margin} must be finite."); return 4
    if a.w_field > 0.0 and not a.field_labels:
        print("  REFUSING: --w-field > 0 needs --field-labels (the SDF label store): the term would have no label."); return 4
    if a.field_shuffle_seed is not None and not a.field_labels:
        print("  REFUSING: --field-shuffle-seed needs --field-labels."); return 4
    # P7.1 (SPEC_AUX_DRIVABLE_HEAD.md section 4, SPEC_P7 section 1). EVERY default builds nothing (--w-aux-drv 0.0, no --aux-drv): a head-less arm cannot silently carry one, and an arm that
    # means the head NAMES --aux-drv AND --w-aux-drv > 0. A lever named without the head, a head without labels, a head with no weight, a feed this trainer does not build: refused.
    bad_aux = list(AUX.aux_refusals(a))
    if a.aux_drv and not (0.0 < a.w_aux_drv < float("inf")):
        bad_aux.append(f"--aux-drv needs --w-aux-drv > 0 (got {a.w_aux_drv}): a head with no weight is built, trained by nothing and carried in every checkpoint -- the head-off twin simply omits --aux-drv")
    if a.aux_drv and a.aux_drv_feed != "off":
        bad_aux.append("--aux-drv-feed on (H2) is not built in the trunk trainer: the scorer-side feed needs the planner / model.py path (WIRING_PLAN 3.10) -- this trainer builds H1 only")
    if bad_aux:
        for m_ in bad_aux:
            print(f"  REFUSING: {m_}")
        return 4
    if a.nav_mode != "goal":
        cfg.nav_mode = a.nav_mode
        print(f"  NAV MODE: {a.nav_mode} -- the student is conditioned on the discrete navigation command (the paper's input), not on goal points")
    # ⭐ EVERY DEPARTURE IS A FLAG, AND EVERY FLAG IS PRINTED. A run that silently differs from the
    # default is how an ablation becomes an unexplained result three weeks later.
    if a.n_cameras is not None:
        cfg.n_cameras = a.n_cameras
        cfg.cameras = tuple(cfg.cameras[:a.n_cameras])
        print(f"  ABLATION: rig reduced to {a.n_cameras} camera(s) {cfg.cameras}")
    if not a.undistort:
        cfg.undistort = False
        print("  ABLATION: ideal-pinhole frustum (lens distortion NOT inverted)")
    if not a.detach_scorer_context:
        cfg.detach_scorer_context = False
        print("  ABLATION: the PDM loss reaches the backbone LoRA (REFe's extra detach removed)")
    torch.manual_seed(a.seed)
    model = REFe(cfg)

    # ⛔⛔ LOAD THE PRETRAINED TRUNK. UNTIL 2026-09-23 THIS FILE DID NOT, AND NOTHING NOTICED.
    # `REFe(cfg)` builds the backbone at RANDOM init; `load_dinov3.map_into_backbone` is the only
    # thing that fills it, and the sole importer of that module was `diag_rope.py`. The trainer
    # would therefore have trained a FROZEN RANDOM TRUNK -- the premise of the method inverted --
    # while the loss still fell, because the LoRA adapters and both heads learn regardless.
    # MEASURED on ViT-S: the mapper reports loaded=186 missing=0 unused=0 and **186 backbone
    # tensors MOVE**; `cls_token` and `reg_token` read all-zeros before it runs. ⚠️ The banked
    # overfit control (1.9316 -> 0.3730) would have passed identically -- overfitting 8 scenarios
    # does not need good features -- and `diag_rope` stayed green because IT loads the weights
    # itself. Advisory class A sitting inside class F.
    if a.weights != "none":
        import load_dinov3 as LD
        wdir = a.weights or os.path.join(LD.BACKBONE_ROOT, BACKBONES[a.backbone]["weights"])
        sd = LD.load_state(wdir)
        loaded, missing, unused = LD.map_into_backbone(model.backbone, sd)
        print(f"  trunk: loaded {len(loaded)} tensors from {wdir} "
              f"(missing {len(missing)}, unused {len(unused)})")
        # ⛔ A LOAD THAT SILENTLY NO-OPS IS THE SAME DEFECT WEARING A PRINT STATEMENT. Refuse.
        if not loaded:
            print("  REFUSING TO TRAIN: the checkpoint mapped 0 tensors into the backbone.")
            return 3
        if missing or unused:
            print(f"  REFUSING TO TRAIN: incomplete mapping -- missing={missing[:4]} "
                  f"unused={unused[:4]}. A partially-loaded trunk is not the published backbone.")
            return 3
    else:
        print("  *** --weights none: FROZEN RANDOM TRUNK. An ABLATION, not a reproduction; no "
              "number from it may be compared with the paper. ***")
    warm = None
    if a.init_from:
        if not os.path.exists(a.init_from):
            print(f"  REFUSING: --init-from {a.init_from} does not exist"); return 4
        warm = warm_start(model, a.init_from)
        print(f"  WARM START (PREREG_P2): {warm['tensors']} tensors from {a.init_from} "
              f"({warm['format']}, sha256 {warm['sha256'][:12]})")
    if a.pdm_only and not (a.pdm_labels and a.scorer_mode == "onpolicy"):
        print("  REFUSING: --pdm-only needs --pdm-labels and --scorer-mode onpolicy"); return 4
    # fingerprint the FROZEN trunk once, on CPU, before the move: it is what makes a partial
    # checkpoint safe to complete (ckpt_io.load_partial refuses a different trunk).
    frozen_sha = ckpt_io.frozen_fingerprint(model) if a.out else None
    model = model.to(dev)
    if a.compile and dev == "cuda":
        # ⭐ nn.Module.compile() compiles IN PLACE: parameter names and state_dict keys are unchanged,
        # so checkpoints, resume and planner.py's strict load are unaffected. (`torch.compile(module)`
        # would return a wrapper whose keys all gain an `_orig_mod.` prefix.) MEASURED on the A40:
        # bf16 + compiled backbone 0.220 s/sample vs 0.366 eager (1.66x); ~2 min compile, once per shape.
        model.backbone.compile()
    # ---- P7.1: the training-only drivable-area head, a SIBLING of the model (never a submodule: it must not reach ckpt_io.full_state / the planner's strict load). Built only under --aux-drv.
    # `aux_cap` is the tap: a forward hook on `scene_proj` collects its TWO outputs of one forward (call 1 = scene_ctx [B, 64, 256], call 2 = visual_ctx [B, P, 256], model.py forward), live only
    # around the training forward. `aux_params` is [] without the head, so the optimiser / clip lists below are then the very lists they always were.
    aux = None
    aux_params: list = []
    aux_cap = {"on": False, "taps": []}
    if a.aux_drv:
        aux = AUX.AuxDrivable(AUX.AuxDrivableConfig.from_args(a)).to(dev)
        aux_params = list(aux.parameters())
        model.scene_proj.register_forward_hook(lambda _m, _i, o: aux_cap["taps"].append(o) if aux_cap["on"] else None)
        print(f"  P7.1 AUX DRIVABLE-AREA HEAD (training-only, H1): tap {a.aux_drv_tap}  depth {a.aux_drv_depth}  w_aux {a.w_aux_drv:g}  {sum(p.numel() for p in aux_params):,} parameters  "
              f"(not in model_final.pt's `model`: the planner is unchanged)")
    rep = param_report(model)
    print(f"  REFe {a.backbone} {rep['total']/1e6:.2f} M total / {rep['trainable']/1e6:.2f} M "
          f"trainable ({rep['pct']:.2f} %)  device={dev}")
    # WTA gives gradient to ONE proposal per SAMPLE, so at most `batch` of M proposals are touched
    # per step. Printed because it is a property of the RUN, not of the model, and it is what
    # decides whether the 64 proposals specialise at all. Their training used batch 256.
    print(f"  WTA reach: at most {a.batch} of {cfg.n_proposals} proposals updated per step "
          f"({100*a.batch/cfg.n_proposals:.1f} %)")
    if a.synthetic:
        print("  *** SYNTHETIC IMAGES: this run validates the LOOP MECHANICS ONLY.")
        print("  *** Its loss says nothing about driving and must not be quoted as a result.")

    OP = None
    if a.scorer_mode == "onpolicy":
        if not a.onpolicy_targets:
            print("  REFUSING: --scorer-mode onpolicy needs --onpolicy-targets (the directory the "
                  "labeller writes onpolicy_*.jsonl into).")
            return 4
        OP = a.onpolicy_targets
        print(f"  SCORER: ON-POLICY (PI decision 2026-09-26, B) -- the scorer is trained on the "
              f"student's own proposals scored by the teacher, from {OP}; the fixed candidate set "
              f"is NOT used")
    grow_snap = None
    if a.grow:
        if a.epochs and not a.grow_scenes:
            print("  REFUSING: --grow with --epochs needs --grow-scenes, the FINAL scene count the "
                  "schedule is sized for -- the bank is still growing, so its size now is not it.")
            return 4
        ck0 = Path(a.out) / "ckpt_last.pt" if a.out else None
        if a.resume and ck0 is not None and ck0.exists():
            # resuming INSIDE an epoch: that epoch's bank is the one it started with, byte for byte
            grow_snap = torch.load(ck0, map_location="cpu", weights_only=False)["state"].get(
                "bank_snapshot")
            if grow_snap is not None and os.environ.get("REFE_GROW_MUTATE_FRESH_SNAPSHOT") == "1":
                print("  *** DELIBERATE REGRESSION: resume IGNORES the checkpoint's bank snapshot")
                grow_snap = None
        src_ck = grow_snap is not None
        if grow_snap is None:
            grow_snap = bank_snapshot(a.targets, a.scorer_targets, OP)
        print(f"  GROW: bank snapshot {len(grow_snap)} files, {sum(grow_snap.values()):,} bytes"
              f"{' (the checkpointed epoch snapshot)' if src_ck else ' (taken now)'}")
    # ⭐ ON-POLICY MODE (PI decision 2026-09-26, B): the fixed candidate bank is NOT loaded -- the
    # paper supervises the scorer with the student's own proposals only, and at full scale the fixed
    # bank costs GBs of Python lists in every DataLoader worker for rows this mode never reads.
    scorer_bank = ScorerBank(a.scorer_targets if not (OP or online) else None, sizes=grow_snap)
    op_bank = None
    if OP:
        op_bank = OnPolicyBank(OP, cfg.n_proposals, cfg.horizon_steps, sizes=grow_snap,
                               pdm_labels=a.pdm_labels or None, pdm_only=a.pdm_only)
        if a.pdm_labels:
            print(f"  PDM TARGETS (PREREG_P2): {op_bank.n_pdm:,} sets carry NAVSIM PDM targets ({op_bank.n_pdm_stale} "
                  f"stale, {op_bank.n_pdm_superseded} superseded) <- {a.pdm_labels}"
                  + (f"; --pdm-only dropped {op_bank.n_dropped_non_pdm:,} sets without them" if a.pdm_only else ""))
        print(f"  ON-POLICY scorer bank: {len(op_bank.by):,} complete sets ({op_bank.n_rows:,} set lines, "
              f"{op_bank.n_incomplete} incomplete, {op_bank.n_superseded} superseded by a newer "
              f"checkpoint, {op_bank.n_bad_lines} unparseable lines; NAVSIM drivable area on "
              f"{op_bank.n_navsim_dac:,} sets) <- {OP}"
              + ("   [none yet in this epoch's snapshot: the scorer gets NO loss until the next "
                 "epoch boundary]" if not op_bank.by else ""))
    if scorer_bank.n_rows:
        print(f"  scorer bank: {scorer_bank.n_rows:,} rows over "
              f"{len(scorer_bank.by):,} frames  <- {a.scorer_targets}")
        if scorer_bank.n_legacy_norank:
            print(f"  *** {scorer_bank.n_legacy_norank:,} rows carry NO `rank` field and are being "
                  f"read as rank 0.")
            print(f"  *** Every rank-1 training tuple therefore MISSES, and coverage halves "
                  f"SILENTLY. Rebuild the bank with --rank before quoting a scorer number.")
        print(f"      {'component':14s} {'mean':>6s} {'pooled sd':>10s} {'varies in':>10s}"
              f"   <- 'varies in' is the fraction of FRAMES whose candidates differ at all")
        for name, mean, sd, frac, inert in scorer_bank.variance_report():
            flag = "  *** CANNOT RANK: constant within every frame" if inert else ""
            print(f"      {name:14s} {mean:6.3f} {sd:10.3f} {100*frac:9.1f} %{flag}")
    elif online:
        print("  SCORER (P6): ONLINE PDM labeller -- each micro-batch's OWN proposals are scored by NAVSIM's simulator while the next forward runs (lag 0); "
              "the fixed candidate bank is NOT loaded")
    elif not OP:
        print("  scorer bank: NONE -- the scorer falls back to the zero PLACEHOLDER and "
              "proposal selection stays arbitrary")
    ds = TargetBank(a.targets, a.images, cfg, synthetic=a.synthetic,
                    limit=a.overfit_n if a.overfit else None, spread=a.spread,
                    scorer=scorer_bank if scorer_bank.n_rows else None,
                    ego_yaw_table=a.ego_yaw_table or None,                    # WP YAW (None = the unchanged loader)
                    traj_label_table=a.traj_label_table or None,              # P5-C (None = the unchanged loader)
                    max_missing_frac=a.max_missing_images, calib=a.calib, sizes=grow_snap,
                    onpolicy=op_bank, online=online,
                    field_labels=a.field_labels, field_shuffle_seed=a.field_shuffle_seed,
                    aux_labels=a.aux_drv_labels or None, aux_shuffle_seed=a.aux_drv_shuffle_seed)
    if not a.calib:
        print("  *** NO --calib: every tuple is lifted with the ONE baked rig (pre-R22 behaviour). "
              "An ABLATION -- PETR, the paper's cited embedding, uses each sample's own. ***")
    if a.epoch_unit == "scenes":
        sampler = SceneEpochSampler(ds.scene_groups, a.seed, shuffle=not a.overfit)
    else:
        sampler = EpochSampler(len(ds), a.seed, shuffle=not a.overfit)
    epoch_len = sampler.n                    # what ONE epoch passes over: scenes, or rows
    # workers decode JPEGs while the GPU runs; the ORDER still comes from the sampler in this process,
    # so resume stays exact. ⚠️ each worker is a fork holding the banks (~8 GiB at full scale,
    # copy-on-write pages get copied as rows are touched) -- keep workers small under a RAM cap.
    # under --grow the dataset is REPLACED at every epoch boundary, so its workers must not persist
    dl = DataLoader(ds, batch_size=a.batch, sampler=sampler, num_workers=a.workers,
                    drop_last=False, pin_memory=(dev == "cuda"),
                    persistent_workers=a.workers > 0 and not a.grow,
                    prefetch_factor=(4 if a.workers > 0 else None))
    print(f"  bank: {len(ds):,} tuples in {len(ds.scene_groups):,} scenes   epoch = one pass over "
          f"{epoch_len:,} {a.epoch_unit}   batch {a.batch}   "
          f"{'OVERFIT CONTROL on ' + str(a.overfit_n) + ' tuples' if a.overfit else 'training'}")
    # PAPER: "We train DriveZero for 25 EPOCHS with a batch size of 256." This trainer counts
    # STEPS, so until 2026-09-20 the paper's schedule could not be stated in its own unit at all
    # and the cosine T_max had nothing to span. Deriving steps from epochs here -- BEFORE the
    # optimiser is built -- is what makes "decayed to zero over the whole run" mean the run.
    if a.epochs:
        import math as _m
        # ⛔⛔ THIS DIVIDED BY `a.batch` ALONE UNTIL 2026-09-21, AND GRADIENT ACCUMULATION TURNED IT
        # INTO A SILENT 64x OVERRUN. `step` counts OPTIMISER steps; one optimiser step consumes
        # `batch * accum` SAMPLES. Dividing by the micro-batch therefore asked for `accum` times
        # too many steps, and the run consumed `accum` epochs for every epoch requested.
        # MEASURED: `--epochs 2` printed the IDENTICAL step count at `--accum 1` and `--accum 4`
        # while consuming 2 vs 8 epochs of data -- the two runs are indistinguishable from the log.
        # ⚠️ The documented recipe `--batch 4 --accum 64 --epochs 25` would have run **1,601
        # epochs**, and every wall-clock estimate derived from it was 64x optimistic.
        eff = max(a.batch, 1) * max(a.accum, 1)
        # --grow: the schedule is sized for the FINAL bank; epochs early in the run are shorter
        sched_len = a.grow_scenes if a.grow else epoch_len
        per_epoch = max(_m.ceil(sched_len / eff), 1)
        a.steps = a.epochs * per_epoch
        print(f"  schedule from EPOCHS: {a.epochs} x {per_epoch} optimiser steps/epoch "
              f"= {a.steps:,} steps  (effective batch {eff} = {a.batch} x {a.accum}; "
              f"paper: 25 epochs at batch 256)")
        print(f"    -> {a.steps * eff:,} sample-passes = {a.steps * eff / max(sched_len, 1):.2f} "
              f"epochs of {sched_len:,} {a.epoch_unit}   (must equal --epochs, or the derivation "
              f"is wrong){'  [--grow: sized for --grow-scenes, not the bank now]' if a.grow else ''}")

    params = [p for p in model.parameters() if p.requires_grad]
    if aux is not None:
        params += aux_params            # P7.1: the head trains with the trunk -- the same AdamW group, lr and cosine schedule (its gradient reaches the LoRA, so it shares the clip below)
    if a.break_optimizer:
        print("  *** DELIBERATE REGRESSION: optimizer given an EMPTY parameter set.")
        print("  *** If the overfit control still PASSES below, the control is inert.")
        params = [torch.nn.Parameter(torch.zeros(1, device=dev))]
    opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=a.weight_decay,
                            fused=bool(a.fused_adam and dev == "cuda"))
    # PAPER: "AdamW and an initial learning rate of 2 x 10^-4 DECAYED TO ZERO VIA COSINE
    # ANNEALING". Until 2026-09-20 this trainer had NO scheduler at all and a default lr of 3e-4 --
    # an UNINTENDED divergence on both counts, fixed on PI instruction. eta_min is 0.0 because
    # "decayed to zero" is the paper's words, not a rounding of some small floor.
    sched = None
    if a.cosine:
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(a.steps, 1), eta_min=0.0)
    print(f"  optimiser: AdamW lr {a.lr:g} wd {a.weight_decay:g}  schedule: "
          f"{'cosine -> 0 over ' + str(a.steps) + ' steps' if sched else 'NONE (--no-cosine)'}")

    first, last, t0 = None, None, time.time()
    step, n_cov, n_seen, assign_d = 0, 0, 0, float("nan")
    per_cand = [[0.0, 0] for _ in CAND_NAMES]
    # ⛔ A WHOLE-RUN MEAN CANNOT ANSWER THE QUESTION THIS TABLE IS FOR. The accumulator above spans
    # every step INCLUDING the untrained ones -- MEASURED 2026-09-20, step 0 read 11.89 m and the
    # last steps read ~5.4 m, so a run-average of 3.54 m for `teacher` is a blend of "the model was
    # bad at the start" and "the supervision is mis-assigned". Those are exactly the two things the
    # per-candidate report exists to separate, so the run-average silently re-conflates them.
    # ⇒ a TRAILING window, accumulated only over the last quarter of the run, is the number that
    # answers "where is the supervision landing NOW". Both are printed; neither is quoted alone.
    per_cand_late = [[0.0, 0] for _ in CAND_NAMES]
    late_from = int(a.steps * 0.75)
    n_uncovered = 0
    # on-policy selection window (pick / random / best label aggregate, n sets, summed label lag),
    # reported and reset at every log line -- a diagnostic, not resume state
    op_win = [0.0, 0.0, 0.0, 0, 0.0]
    micro = 0
    # ⭐ THE CONSTANT SCORE NORMALISER, derived from the BANK rather than from any micro-batch, so
    # gradient accumulation is exactly equivalent to one large batch (see the note at `l_score`).
    # Mean covered candidates per SAMPLE across the whole training set, floored at 1 so an
    # uncovered bank cannot divide by zero.
    cov_norm = 1.0
    if scorer_bank is not None and getattr(scorer_bank, "by", None) and len(ds) > 0:
        # the bank keys COVERED frames; dividing the total banked candidates by the FULL dataset
        # size is exactly the mean covered candidates per sample, which is what the loss needs.
        cov_norm = max(sum(len(e["traj"]) for e in scorer_bank.by.values()) / float(len(ds)), 1e-3)
    if op_bank is not None:
        cov_norm = onpolicy_cov_norm(ds, op_bank, cfg.n_proposals)
    lab = None
    if online:
        import online_labeller as OL
        # a CONSTANT denominator (all M proposals of every sample): a guard-skipped sample contributes LESS gradient instead of being upweighted, and
        # --accum stays exactly equivalent to one large batch
        cov_norm = float(cfg.n_proposals)
        lab = OL.OnlineLabeller(backend=a.label_backend, workers=a.label_workers, metric_cache=a.metric_cache or None, timeout_s=a.label_timeout_s,
                                python=a.label_python or None, n_prop=cfg.n_proposals, horizon=cfg.horizon_steps, chunks=a.label_chunks)
        print(f"  ONLINE LABELLER: backend {a.label_backend}  workers {a.label_workers}  chunks/set {a.label_chunks}  metric cache {a.metric_cache}  timeout {a.label_timeout_s:g} s")
    print(f"  score-loss normaliser: {cov_norm:.4f} covered candidates/sample x batch "
          f"(CONSTANT, so --accum is exactly equivalent to one large batch)")
    opt.zero_grad(set_to_none=True)          # the window is opened here, then after every step
    if a.accum > 1:
        print(f"  gradient accumulation: {a.accum} micro-batches of {a.batch} "
              f"= effective batch {a.accum * a.batch}  (paper: 256)")

    # ⭐ RUN DIRECTORY. config.json (what ran) · metrics.jsonl (every logged step) · ckpt_last.pt
    # (resume: partial model + optimiser + schedule + data position + RNG) · snap_epochNNN.pt
    # (partial weights per epoch, for learning-curve evals) · model_final.pt (FULL, what
    # planner.py loads) · summary.json {"done": true} LAST -- the supervisor's off-switch.
    epoch, pos, elapsed0 = 0, 0, 0.0
    run_dir = Path(a.out) if a.out else None
    ident = None
    meta = {}
    if run_dir is not None:
        run_dir.mkdir(parents=True, exist_ok=True)
        ident = run_identity(a, ds, scorer_bank, frozen_sha)
        if a.weights == "none":
            wdir_used = "none"
        else:
            import load_dinov3 as _LD
            wdir_used = a.weights or os.path.join(_LD.BACKBONE_ROOT,
                                                  BACKBONES[a.backbone]["weights"])
        meta = {"backbone": a.backbone, "weights_dir": wdir_used, "frozen_sha256": frozen_sha,
                "per_sample_calib": bool(a.calib),
                "n_cameras": cfg.n_cameras, "cameras": list(cfg.cameras)}
        if cfg.nav_mode != "goal":
            meta["nav_mode"] = cfg.nav_mode         # ckpt_io.config_for_checkpoint: the planner builds the SAME model (absent => goal, every checkpoint before P6)
        if a.traj_label_table:
            # P5-C: a checkpoint trained on table labels says so (the table's sha256 + coverage); absent => the WTA target was the bank's raw traj (every checkpoint before P5-C)
            meta["traj_label_table_sha256"] = ds.traj_label_sha256
            meta["traj_label_coverage"] = ds.traj_label_cov
            meta["traj_label_rank_policy"] = ds.traj_label_cov.get("rank_policy")      # all | rank0 | identity: what the table DECLARED and apply_to_rows enforced on this bank's rows
        if a.ego_yaw_table:
            # WP YAW: a checkpoint trained with a REAL ego[4] says so (refe/ego_yaw.py reads these at deploy to feed the same yaw rate); absent => ego[4] was 0.0 in training (every checkpoint before WP YAW)
            meta["ego_yaw"] = EYT.YAW_TAG
            meta["ego_yaw_table_sha256"] = ds.ego_yaw_sha256
            meta["ego_yaw_scale"] = EYT.YAW_SCALE              # the model reads ego[4] = ego_yaw_scale x rad/s; ego_yaw.py multiplies by THIS value and refuses a yaw checkpoint without one
            meta["ego_yaw_slot"] = EYT.EGO_YAW_SLOT
        ck_path = run_dir / "ckpt_last.pt"
        summ = run_dir / "summary.json"
        if summ.exists():
            try:
                done = bool(json.load(open(summ, encoding="utf-8")).get("done"))
            except Exception:
                done = False
            if done:
                print(f"  REFUSING: {summ} says this run is FINISHED (done=true). A supervisor "
                      f"relaunching it would overwrite a completed model. Use a new --out.")
                print("TRAIN_ALREADY_DONE")
                return 0
        if ck_path.exists() and not a.resume:
            print(f"  REFUSING: {ck_path} exists. Pass --resume to continue that run, or choose a "
                  f"new --out -- starting over would silently overwrite it.")
            return 4
        if a.resume and ck_path.exists():
            st = torch.load(ck_path, map_location="cpu", weights_only=False)
            accepted: list = []
            diff = _identity_diff(st["identity"], ident, declared=tuple(a.declare_change or ()),
                                  accepted=accepted)
            if diff:
                print("  REFUSING TO RESUME -- the run's identity changed:")
                for d_ in diff:
                    print(f"      {d_}")
                return 4
            ckpt_io.load_partial(model, st["model_partial"], st["meta"].get("frozen_sha256"))
            opt.load_state_dict(st["opt"])
            if aux is not None:
                if "aux_drv" not in st:
                    print(f"  REFUSING TO RESUME: --aux-drv is on but {ck_path} carries no `aux_drv` head state (the identity check passed, so this checkpoint is damaged).")
                    return 4
                aux.load_state_dict(st["aux_drv"])
            if sched is not None and st.get("sched") is not None:
                sched.load_state_dict(st["sched"])
            S = st["state"]
            step, micro, epoch, pos = S["step"], S["micro"], S["epoch"], S["pos"]
            first, last, elapsed0 = S["first"], S["last"], S["elapsed_s"]
            n_cov, n_seen, n_uncovered = S["n_cov"], S["n_seen"], S["n_uncovered"]
            per_cand, per_cand_late = S["per_cand"], S["per_cand_late"]
            _set_rng_state(st["rng"])
            print(f"  RESUMED {ck_path}: step {step:,}/{a.steps:,}  epoch {epoch}  sample "
                  f"{pos:,}/{len(ds):,}  (saved {st.get('saved_at', '?')})")
            for d_ in accepted:
                print(f"  DECLARED RECIPE CHANGE at this resume (--declare-change): {d_}")
            if a.preflight:
                # READ-ONLY: nothing is appended to a live run's metrics.jsonl or checkpoint
                print(f"  PREFLIGHT: checkpoint loads, identity {'matches' if not accepted else 'differs ONLY by the declared change(s)'}, "
                      f"cov_norm {cov_norm:.4f}")
                print("PREFLIGHT_OK")
                return 0
            _append_jsonl(run_dir / "metrics.jsonl",
                          {"event": "resume", "step": step, "epoch": epoch, "pos": pos,
                           "at": _now()})
            if accepted:
                _append_jsonl(run_dir / "metrics.jsonl",
                              {"event": "declared_change", "changes": accepted, "step": step,
                               "epoch": epoch, "at": _now()})
        else:
            if a.resume:
                print(f"  --resume: no {ck_path.name} yet -- starting fresh")
            if a.preflight:
                print(f"  PREFLIGHT: fresh start, cov_norm {cov_norm:.4f}; nothing written")
                print("PREFLIGHT_OK")
                return 0

            def _src(f):
                q = Path(__file__).resolve().parent / f
                return ckpt_io.sha256_file(q) if q.exists() else None
            cfg_out = {"argv": sys.argv,
                       "args": {k: (v if isinstance(v, (int, float, str, bool, type(None)))
                                    else str(v)) for k, v in vars(a).items()},
                       "identity": ident, "meta": meta, "warm_start": warm,
                       "params": {"total": rep["total"], "trainable": rep["trainable"]},
                       "torch": torch.__version__,
                       "device": torch.cuda.get_device_name(0) if dev == "cuda" else "cpu",
                       "source_sha256": {f: _src(f) for f in
                                         ("train.py", "model.py", "load_dinov3.py", "ckpt_io.py")},
                       "started_at": _now()}
            if aux is not None:
                cfg_out["aux_drv"] = {**aux.built_facts(), "tap": a.aux_drv_tap, "feed": a.aux_drv_feed, "labels": a.aux_drv_labels, "source_sha256": _src("aux_drivable_head.py")}
            with open(run_dir / "config.json", "w", encoding="utf-8") as f:
                json.dump(cfg_out, f, indent=1)
            _append_jsonl(run_dir / "metrics.jsonl", {"event": "start", "at": _now()})

    def _state():
        return {"step": step, "micro": micro, "epoch": epoch, "pos": pos, "first": first,
                "last": last, "elapsed_s": time.time() - t0, "n_cov": n_cov, "n_seen": n_seen,
                "n_uncovered": n_uncovered, "per_cand": per_cand, "per_cand_late": per_cand_late,
                "bank_snapshot": grow_snap}

    def _bank_event():
        pr: dict = {}
        for r_ in ds.rows:
            pr[str(int(r_.get("rank", 0)))] = pr.get(str(int(r_.get("rank", 0))), 0) + 1
        ev = {"event": "bank", "epoch": epoch, "n_tuples": len(ds),
              "n_scenes": len(ds.scene_groups), "per_rank": pr,
              "scorer_frames": len(getattr(scorer_bank, "by", {}) or {}),
              "cov_norm": cov_norm, "snapshot_bytes": sum(grow_snap.values()) if grow_snap else None,
              "at": _now()}
        if online:                           # P6 / G-CLOCK: step-0 bank, registered schedule and where the commands come from
            ev.update({"labeller": "online", "label_backend": a.label_backend, "nav_mode": cfg.nav_mode, "yaw_wrap": a.yaw_wrap,
                       "epochs": a.epochs, "steps": a.steps, "epoch_len": epoch_len, "accum": a.accum, "batch": a.batch,
                       "command_sources": getattr(ds, "cmd_sources", None)})
        if op_bank is not None:              # on-policy mode only: a fixed run's rows are unchanged
            ev.update({"scorer_mode": "onpolicy", "onpolicy_sets": len(op_bank.by),
                       "onpolicy_navsim_dac_sets": op_bank.n_navsim_dac,
                       "onpolicy_incomplete": op_bank.n_incomplete,
                       "onpolicy_superseded": op_bank.n_superseded})
        return ev

    def _rebuild(snap):
        """--grow: the next epoch's bank, from a fresh snapshot (same construction as above)."""
        sb = ScorerBank(a.scorer_targets if not OP else None, sizes=snap)
        ob = (OnPolicyBank(OP, cfg.n_proposals, cfg.horizon_steps, sizes=snap, pdm_labels=a.pdm_labels or None,
                           pdm_only=a.pdm_only) if OP else None)
        d = TargetBank(a.targets, a.images, cfg, synthetic=a.synthetic,
                       limit=a.overfit_n if a.overfit else None, spread=a.spread,
                       scorer=sb if sb.n_rows else None,
                       ego_yaw_table=a.ego_yaw_table or None,
                       traj_label_table=a.traj_label_table or None,
                       max_missing_frac=a.max_missing_images, calib=a.calib, sizes=snap,
                       onpolicy=ob, field_labels=a.field_labels, field_shuffle_seed=a.field_shuffle_seed,
                       aux_labels=a.aux_drv_labels or None, aux_shuffle_seed=a.aux_drv_shuffle_seed)
        smp = (SceneEpochSampler(d.scene_groups, a.seed, shuffle=not a.overfit)
               if a.epoch_unit == "scenes" else EpochSampler(len(d), a.seed, shuffle=not a.overfit))
        ld = DataLoader(d, batch_size=a.batch, sampler=smp, num_workers=a.workers,
                        drop_last=False, pin_memory=(dev == "cuda"), persistent_workers=False,
                        prefetch_factor=(4 if a.workers > 0 else None))
        cn = 1.0
        if getattr(sb, "by", None) and len(d) > 0:
            cn = max(sum(len(e["traj"]) for e in sb.by.values()) / float(len(d)), 1e-3)
        if ob is not None:
            cn = onpolicy_cov_norm(d, ob, cfg.n_proposals)
        return sb, d, smp, ld, cn, ob

    def _aux_ckpt() -> dict:
        """P7.1: the head rides BESIDE `model` in every checkpoint dict (never inside it: the planner's strict load of `model` is unchanged). {} without the head: the dicts are then byte for byte what they were."""
        if aux is None:
            return {}
        return {"aux_drv": aux.state_dict(), "aux_drv_meta": {**aux.built_facts(), "tap": a.aux_drv_tap, "feed": a.aux_drv_feed, "store_sha256": ds.aux.manifest["store_sha256"]}}

    def _save_ckpt():
        nbytes = ckpt_io.atomic_save(
            {"format": ckpt_io.FORMAT_PARTIAL, "model_partial": ckpt_io.partial_state(model),
             "meta": meta, "opt": opt.state_dict(),
             "sched": sched.state_dict() if sched is not None else None,
             "state": _state(), "rng": _rng_state(), "identity": ident, "saved_at": _now(), **_aux_ckpt()},
            run_dir / "ckpt_last.pt")
        _append_jsonl(run_dir / "metrics.jsonl",
                      {"event": "ckpt", "step": step, "epoch": epoch, "pos": pos,
                       "bytes": nbytes, "at": _now()})

    t0 = time.time() - elapsed0          # printed elapsed continues across resumes
    last_ck = time.time()
    if (a.grow or online) and run_dir is not None:
        _append_jsonl(run_dir / "metrics.jsonl", _bank_event())
    if ds.field is not None and run_dir is not None:
        # L_field: what the loader was BUILT with, written by the trainer itself (G-DVB / the weight rule read it): the store's pinned manifest sha256 and key count, and
        # the share of this bank's rows that have a stored label
        _append_jsonl(run_dir / "metrics.jsonl", {"event": "field", "step": step, "w_field": a.w_field, "margin": a.field_margin, "interp": a.field_interp,
                                                  "shuffle_seed": a.field_shuffle_seed, "store_sha256": ds.field.manifest["store_sha256"],
                                                  "store_keys": ds.field_cov["store_keys"], "rows": ds.field_cov["rows"], "rows_labelled": ds.field_cov["labelled"],
                                                  "at": _now()})
    if aux is not None and run_dir is not None:
        # P7.1: what the head was BUILT with, written by the trainer itself (G-DVB reads it): the built facts, the tap, and the store's manifest sha256 / key count / label coverage of the bank's rows
        _append_jsonl(run_dir / "metrics.jsonl", {"event": "aux", "step": step, **aux.built_facts(), "tap": a.aux_drv_tap, "feed": a.aux_drv_feed, "shuffle_seed": a.aux_drv_shuffle_seed,
                                                  "store_sha256": ds.aux.manifest["store_sha256"], "store_keys": ds.aux_cov["store_keys"], "rows": ds.aux_cov["rows"],
                                                  "rows_labelled": ds.aux_cov["labelled"], "at": _now()})
    pend = None                              # online labeller: the micro-batch whose labels have not been consumed yet (its graph is alive)
    bce_comp = [float("nan")] * 6
    t_log0 = time.time()
    field_on = bool(a.field_labels)
    while step < a.steps:
        sampler.set_epoch(epoch, start=pos)
        for batch in dl:
            img, ego, goal, tgt, cand_xy, cand_tg, cand_m, cand_id, cal = batch[:9]
            # L_field: the loader appends (sdf int8 [B,160,128], valid bool [B]) as the LAST TWO elements, after the online row index -- so the index is found by its
            # position among the elements that precede them, and the field elements by negative index. Without --field-labels this is the unchanged `batch[9]`.
            ridx = batch[9] if len(batch) > 9 + (2 if field_on else 0) + (2 if aux is not None else 0) else None
            sdf_t = valid_t = None
            tail_end = len(batch) - (2 if aux is not None else 0)          # P7.1: the head's (sdf, valid) is the very LAST pair, after L_field's when both ride
            if field_on:
                sdf_t, valid_t = batch[tail_end - 2].to(dev, non_blocking=True), batch[tail_end - 1].to(dev, non_blocking=True)
            aux_lab = aux_valid = None
            if aux is not None:
                aux_lab, aux_valid = batch[-2].to(dev, non_blocking=True), batch[-1].to(dev, non_blocking=True)
            img, ego, goal, tgt, cand_xy, cand_tg, cand_m, cand_id = (
                x.to(dev, non_blocking=True)
                for x in (img, ego, goal, tgt, cand_xy, cand_tg, cand_m, cand_id))
            # the rig stays on the CPU in float64: the model uses it as a cache key, not a tensor op
            op_live = OP is not None and float(cand_m.sum()) > 0
            aux_cap["taps"].clear()
            aux_cap["on"] = aux is not None            # P7.1: the tap is live for THIS forward only
            with torch.autocast("cuda", dtype=torch.bfloat16,
                                enabled=(a.amp == "bf16" and dev == "cuda")):
                if op_live:
                    # the labelled sets ride along: scored by the SAME decoder, as their own sets
                    traj, score, sx = model(img, ego, goal, calib=cal if cal.numel() else None,
                                            score_extra=cand_xy)
                else:
                    traj, score = model(img, ego, goal, calib=cal if cal.numel() else None)
                if aux is not None:
                    # P7.1: the head reads ONE tensor, image-derived: visual_ctx (scene_proj's 2nd output) or scene_ctx (its 1st). No ego, goal, navigation command or map (SPEC_AUX 6).
                    aux_cap["on"] = False
                    if len(aux_cap["taps"]) != 2:
                        raise RuntimeError(f"P7.1 tap: scene_proj ran {len(aux_cap['taps'])} times in one forward, expected 2 (scene_ctx, visual_ctx): model.py's forward changed under the head")
                    aux_logit, aux_sdf = aux.predict(aux_cap["taps"][1 if a.aux_drv_tap == "visual" else 0])
            traj, score = traj.float(), score.float()      # every loss and assignment in FP32
            # P6 / D5: --yaw-wrap on (default) is today's wrapped yaw L1, bit for bit; off is the paper's literal L1. parts=True returns the two terms the
            # P6 profile logs (pos_L1, yaw_L1); the sum l_traj is the same expression as before.
            l_traj, idx, l_pos, l_yaw = wta_loss(traj, tgt, yaw_wrap=(a.yaw_wrap == "on"), parts=True)
            # L_field (eval/PREREG_AUX_FIELD_LOSS_DRAFT.md): a hinge on the footprint corners of ALL proposals against the stored SDF. Computed ONLY when --w-field > 0, so a
            # run without it executes exactly the operations it did before this term existed (tested: bit-identical losses, gradients and parameters).
            l_field = fparts = None
            if a.w_field > 0.0:
                l_field, fparts = field_loss(traj, sdf_t, margin=a.field_margin, valid=valid_t, interp=a.field_interp, return_parts=True)
            # P7.1: L_aux = BCE(mask) + Huber(SDF) over the frames WITH a label (a frame without one contributes exactly 0). Computed ONLY under --aux-drv.
            l_aux = aux_bce = aux_hub = None
            if aux is not None:
                l_aux, aux_bce, aux_hub = aux.loss(aux_logit, aux_sdf, aux_lab, aux_valid)
                aux_cap["taps"].clear()
            n_cand = float(cand_m.sum())
            if online:
                # ⭐ P6 / D1 + D2 + D4. The scorer scored ITS OWN proposals (`score`, candidates detached inside the model); their detached copies go to the
                # CPU pool NOW; the loss on them is taken only when their labels return (deferred backward, below). No extra forward, lag 0.
                props_np = traj.detach().double().cpu().numpy()
                metas = [{k: ds.rows[int(j)].get(k) for k in ("log_name", "token", "rank", "aug", "step")} for j in ridx]
                cur = {"stamp": micro, "step": step, "B": int(img.shape[0]), "score": score, "l_traj": l_traj, "l_pos": l_pos, "l_yaw": l_yaw,
                       "idx": idx, "props": props_np, "h": lab.submit(micro, step, metas, props_np), "l_field": l_field, "fparts": fparts,
                       "l_aux": l_aux, "aux_bce": aux_bce, "aux_hub": aux_hub}
                l_score = None
            elif OP is not None:
                if op_live:
                    # ⭐ THE PAPER'S SUPERVISION: every labelled trajectory's six predicted components
                    # against the teacher simulator's verdict on THAT trajectory -- no assignment.
                    sx = sx.float()
                    per = F.binary_cross_entropy_with_logits(sx, cand_tg, reduction="none").mean(-1)
                    # the same CONSTANT denominator as the fixed path (see the note there)
                    denom = max(cov_norm * float(img.shape[0]), 1.0)
                    l_score = (per * cand_m).sum() / denom * a.score_w
                    with torch.no_grad():
                        # op_drift: labelled trajectory -> nearest CURRENT proposal. It no longer
                        # bounds the supervision (each label meets its own path); it says how far the
                        # labelling checkpoint's proposals are from what the model proposes now.
                        d = ((traj[:, :, :, :2].unsqueeze(1) - cand_xy[:, :, :, :2].unsqueeze(2)) ** 2) \
                            .sum(-1).mean(-1)                                           # [B, M, M]
                        dmin = d.min(-1).values.clamp(min=0).sqrt()                     # [B, M]
                        assign_d = float((dmin * cand_m).sum() / cand_m.sum().clamp(min=1.0))
                        # selection on the labelled sets, the training-side twin of SPEC E-6
                        has = cand_m[:, 0] > 0
                        pa = _pdm_aggregate(torch.sigmoid(sx[has]))                     # [b, M]
                        ta = _pdm_aggregate(cand_tg[has])                               # [b, M]
                        pick = ta.gather(1, pa.argmax(1, keepdim=True)).squeeze(1)
                        op_win[0] += float(pick.sum())
                        op_win[1] += float(ta.mean(1).sum())
                        op_win[2] += float(ta.max(1).values.sum())
                        op_win[3] += int(has.sum())
                        op_win[4] += float((step - cand_id[has, 0].float()).sum())      # label lag
                    n_cov += int((cand_m.sum(1) > 0).sum())
                else:
                    l_score = score.sum() * 0.0      # keeps the graph, contributes no gradient
                    n_uncovered += 1
                    assign_d = float("nan")
            elif n_cand > 0:
                # assign each banked candidate to the NEAREST model proposal and supervise THAT
                # proposal's six components. `assign_d` is printed because it BOUNDS the
                # approximation: a large distance means the scorer is being taught about
                # trajectories this model does not produce.
                d = ((traj[:, :, :, :2].unsqueeze(1) - cand_xy.unsqueeze(2)) ** 2)                     .sum(-1).mean(-1)                       # [B, K, M]
                near = d.argmin(-1)                          # [B, K]
                sel = torch.gather(score, 1,
                                   near.unsqueeze(-1).expand(-1, -1, score.shape[-1]))
                per = F.binary_cross_entropy_with_logits(sel, cand_tg, reduction="none").mean(-1)
                # ⛔⛔ NORMALISING BY THIS MICRO-BATCH'S OWN COVERED COUNT BREAKS ACCUMULATION.
                # Under `--accum N` the window's gradient should equal the gradient of the same
                # loss on the full effective batch, i.e. `sum_i(S_i) / sum_i(n_i)`. Dividing each
                # micro-batch by its OWN `n_i` and then by `accum` gives `mean_i(S_i / n_i)`, which
                # is only equal when every `n_i` is the same -- and coverage is ~19 %, so they
                # never are. MEASURED by the sixth review: the accumulated score term came out at
                # **0.7500** of its correct value (3 of 4 micro-batches covered, each scaled 1/4).
                # ⭐ THE FIX IS A CONSTANT DENOMINATOR. With a normaliser that does not depend on
                # the micro-batch, `sum_i(S_i / C) / accum == sum_i(S_i) / (C * accum)` exactly
                # matches the full-batch form, and a poorly-covered micro-batch correctly
                # contributes LESS gradient instead of being silently upweighted to parity.
                # `cov_norm` is the bank's mean covered candidates per SAMPLE (computed once at
                # load), times the batch -- so the loss keeps the scale it had before this change
                # and `--score-w` does not need retuning.
                denom = max(cov_norm * float(img.shape[0]), 1.0)
                l_score = (per * cand_m).sum() / denom * a.score_w
                assign_d = float(((d.min(-1).values.clamp(min=0).sqrt() * cand_m).sum()
                                  / cand_m.sum().clamp(min=1.0)))
                n_cov += int((cand_m.sum(1) > 0).sum())
                dmin = d.min(-1).values.clamp(min=0).sqrt()        # [B, K]
                for nm_i in range(len(CAND_NAMES)):
                    sel_m = (cand_id == nm_i) & (cand_m > 0)
                    if bool(sel_m.any()):
                        tot_i, cnt_i = float(dmin[sel_m].sum()), int(sel_m.sum())
                        per_cand[nm_i][0] += tot_i
                        per_cand[nm_i][1] += cnt_i
                        if step >= late_from:
                            per_cand_late[nm_i][0] += tot_i
                            per_cand_late[nm_i][1] += cnt_i
            else:
                # ⛔ A ZERO TARGET IS NOT A NEUTRAL FALLBACK -- it teaches the scorer that EVERY
                # proposal violates EVERYTHING, which is worse than no supervision at all. The
                # original placeholder did exactly that, and it was defensible only while no real
                # targets existed. Now that they do, an uncovered batch contributes NOTHING and is
                # COUNTED, so the fraction of steps with no supervision is visible instead of being
                # quietly filled with a wrong label.
                # MEASURED 2026-09-20: at 25 % frame coverage and batch 8, P(no covered sample in a
                # batch) = 0.75^8 = 10 %, so a tenth of all steps were being taught the wrong thing.
                l_score = score.sum() * 0.0          # keeps the graph, contributes no gradient
                n_uncovered += 1
                assign_d = float("nan")
            n_seen += int(img.shape[0])
            pos += int(img.shape[0])
            if online:
                # ⭐ D4: DEFERRED BACKWARD. Within an accumulation window the weights are fixed, so the proposals of micro-batch k are exactly those of k's
                # own forward. Order: F(k) -> submit(k) [above] -> collect(k-1) -> B(k-1) -> F(k+1); the window's LAST micro-batch is drained before the
                # step, so backward order == forward order (the accumulated gradient is bit-identical to the undeferred one given the same labels).
                done = [pend] if pend is not None else []
                pend = cur
                if (micro + 1) % a.accum == 0:
                    done.append(pend)
                    pend = None
                for P in done:
                    labels_np, mask_np, linfo = lab.collect(P["h"], step)
                    # the array the labeller scored must be THIS micro-batch's own detached proposals (the trainer keeps its own copy and re-hashes it)
                    if any(OL.sha_of(P["props"][j]) != P["h"]["shas"][j] for j in range(P["B"])):
                        raise RuntimeError(f"LABEL/PROPOSAL IDENTITY VIOLATED: the array submitted for labelling is not micro-batch {P['stamp']}'s own proposals")
                    if linfo["stamp"] != P["stamp"] or linfo["lag_steps"] != 0:
                        raise RuntimeError(f"label clock violated: labels stamped {linfo['stamp']} (lag {linfo['lag_steps']} steps) consumed by micro-batch {P['stamp']}")
                    lab_t = torch.from_numpy(labels_np).to(dev)
                    msk = torch.from_numpy(mask_np).to(dev)
                    bce = F.binary_cross_entropy_with_logits(P["score"], lab_t, reduction="none")            # [B, M, 6]
                    per = bce.mean(-1)
                    denom = max(cov_norm * float(P["B"]), 1.0)
                    l_score = (per * msk[:, None]).sum() / denom * a.score_w
                    with torch.no_grad():
                        bce_comp = [float(v) for v in ((bce * msk[:, None, None]).sum((0, 1)) / denom)]
                        has = msk > 0
                        if bool(has.any()):
                            pa = _pdm_aggregate(torch.sigmoid(P["score"][has]))
                            ta = _pdm_aggregate(lab_t[has])
                            pick = ta.gather(1, pa.argmax(1, keepdim=True)).squeeze(1)
                            op_win[0] += float(pick.sum())
                            op_win[1] += float(ta.mean(1).sum())
                            op_win[2] += float(ta.max(1).values.sum())
                            op_win[3] += int(has.sum())
                            op_win[4] += 0.0                      # label lag in steps: asserted 0 above
                        else:
                            n_uncovered += 1
                        n_cov += int(has.sum())
                    tot_ = P["l_traj"] + l_score
                    if a.w_field > 0.0:
                        tot_ = tot_ + a.w_field * P["l_field"]          # L_field rides the same deferred backward as the other two terms
                    if aux is not None:
                        tot_ = aux.combine(tot_, P["l_aux"])           # P7.1 SITE 1 of 2: L_aux rides the SAME deferred backward (always multiplied by w_aux)
                    (tot_ / a.accum).backward()
                    l_traj, l_pos, l_yaw, idx = P["l_traj"], P["l_pos"], P["l_yaw"], P["idx"]
                    l_field, fparts = P["l_field"], P["fparts"]
                    if aux is not None:
                        l_aux, aux_bce, aux_hub = P["l_aux"], P["aux_bce"], P["aux_hub"]
                    assign_d = 0.0                                # the labelled trajectories ARE the current proposals (identity asserted by sha256)
                    del P
            # ⭐ GRADIENT ACCUMULATION. `step` counts OPTIMISER steps, never micro-batches, so
            # `--steps` and the cosine schedule's `T_max` keep meaning the same thing whatever
            # `--accum` is. Dividing by accum makes the accumulated gradient the MEAN over the
            # effective batch, which is what a single large batch would have produced; clipping
            # then sees the real global norm rather than one micro-batch's.
            if not online:
                loss = l_traj + l_score
                if l_field is not None:
                    loss = loss + a.w_field * l_field
                if aux is not None:
                    loss = aux.combine(loss, l_aux)                 # P7.1 SITE 2 of 2 (editing one site leaves the other arm head-less: the 'V2' failure)
                loss = loss / a.accum
                loss.backward()
            micro += 1
            if micro % a.accum:
                continue                     # still filling the window: no step, no step count
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad] + aux_params, 1.0)
            opt.step()
            opt.zero_grad(set_to_none=True)
            if sched is not None:
                sched.step()
            first = first if first is not None else float(l_traj)
            last = float(l_traj)
            if step % a.log_every == 0:
                uniq = len(set(idx.tolist()))
                print(f"    step {step:5d}  traj_L1 {float(l_traj):8.4f}  score {float(l_score):7.4f}  "
                      f"winners {uniq}/{img.shape[0]}  assign_d {assign_d:6.2f} m  "
                      f"scorer_cov {100.0*n_cov/max(n_seen,1):5.1f} %  "
                      f"lr {opt.param_groups[0]['lr']:.2e}  {time.time()-t0:6.1f}s")
                if run_dir is not None:
                    row = {
                        "step": step, "epoch": epoch, "pos": pos, "traj_L1": float(l_traj),
                        "score": float(l_score), "winners": uniq, "batch": int(img.shape[0]),
                        "assign_d": assign_d, "scorer_cov": n_cov / max(n_seen, 1),
                        "lr": opt.param_groups[0]["lr"], "elapsed_s": time.time() - t0,
                        "samples": n_seen,
                        "cuda_max_mem_gb": (torch.cuda.max_memory_allocated() / 2**30
                                            if dev == "cuda" else None),
                        "pos_L1": float(l_pos), "yaw_L1": float(l_yaw)}
                    if l_field is not None:
                        # L_field: the unweighted loss, the multiplier applied to it, the share of in-extent footprint corners with SDF < 0, and the share of corners in extent
                        row.update({"field_L": float(l_field), "field_w": float(a.w_field), "field_viol": float(fparts["violating_frac"]),
                                    "field_inext": float(fparts["in_extent_frac"])})
                    if l_aux is not None:
                        # P7.1: the two terms (unweighted), their sum, and the multiplier the trainer applied
                        row.update({"aux_bce": float(aux_bce), "aux_huber": float(aux_hub), "aux_L": float(l_aux), "aux_w": float(aux.w_aux)})
                    if online:
                        # P6: the six BCE components (NC, DAC, EP, TTC, C, DDC), unweighted, of the step's last micro-batch: score == score_w * mean(bce_*)
                        row.update({"bce_nc": bce_comp[0], "bce_dac": bce_comp[1], "bce_ep": bce_comp[2],
                                    "bce_ttc": bce_comp[3], "bce_c": bce_comp[4], "bce_ddc": bce_comp[5]})
                    _append_jsonl(run_dir / "metrics.jsonl", row)
                    if online:
                        ls = lab.take_stats()
                        dt_w = max(time.time() - t_log0, 1e-9)
                        t_log0 = time.time()
                        _append_jsonl(run_dir / "metrics.jsonl", {
                            "step": step, "event": "labeller", "sets": ls["n_sets"], "labelled": ls["n_labelled"], "no_parts": ls["n_no_parts"],
                            "failed": ls["n_failed"], "stall_s": ls["stall_s"], "stall_frac": ls["stall_s"] / dt_w,
                            "queue_depth": ls["queue_sum"] / max(ls["n_submits"], 1), "lag_hist": ls["lag_hist"],
                            "cpu_s_per_set": ls["cpu_s"] / max(ls["n_sets"], 1), "window_s": dt_w})
                if OP is not None or online:
                    # selection skill on the labelled sets since the last log line: the share of the
                    # gain over a random pick that the scorer's argmax realises (SPEC E-6's measure)
                    n_w = op_win[3]
                    pk, rd, bs = ((op_win[0] / n_w, op_win[1] / n_w, op_win[2] / n_w) if n_w
                                  else (float("nan"),) * 3)
                    sk = (pk - rd) / (bs - rd) if n_w and bs - rd > 1e-9 else float("nan")
                    lag = op_win[4] / n_w if n_w else float("nan")
                    print(f"      on-policy: sets {n_w:4d}  pick {pk:.3f}  random {rd:.3f}  best {bs:.3f}"
                          f"  skill {sk:6.3f}  drift {assign_d:5.2f} m  label lag {lag:7.1f} steps")
                    if run_dir is not None:
                        _append_jsonl(run_dir / "metrics.jsonl", {
                            "step": step, "event": "onpolicy", "sets": n_w, "pick": pk,
                            "random": rd, "best": bs, "skill": sk, "drift_m": assign_d,
                            "lag_steps": lag, "cov_norm": cov_norm})
                    op_win = [0.0, 0.0, 0.0, 0, 0.0]
            step += 1
            # checkpoint only HERE, right after an optimiser step: every consumed sample is then
            # in the weights, so (epoch, pos) is exact and no half-filled window is lost or doubled
            if run_dir is not None and step < a.steps and (
                    time.time() - last_ck >= a.ckpt_every_min * 60.0
                    or (a.ckpt_every_steps and step % a.ckpt_every_steps == 0)):
                _save_ckpt()
                last_ck = time.time()
                if a.halt_after_steps and step >= a.halt_after_steps:
                    print(f"  TEST HALT after the checkpoint at step {step} (--halt-after-steps)")
                    print("TRAIN_HALTED")
                    return 7
            if step >= a.steps:
                break
        else:
            # the loader ran dry without a break: an EPOCH completed
            epoch += 1
            pos = 0
            if run_dir is not None:
                ckpt_io.atomic_save({"format": ckpt_io.FORMAT_PARTIAL,
                                     "model_partial": ckpt_io.partial_state(model),
                                     "meta": dict(meta, epoch=epoch, step=step), "saved_at": _now(), **_aux_ckpt()},
                                    run_dir / f"snap_epoch{epoch:03d}.pt")
                _append_jsonl(run_dir / "metrics.jsonl",
                              {"event": "epoch", "epoch": epoch, "step": step, "at": _now()})
            if a.grow and step < a.steps:
                # the next epoch reads the bank AS IT IS NOW -- a new snapshot, a new sampler
                grow_snap = bank_snapshot(a.targets, a.scorer_targets, OP)
                scorer_bank, ds, sampler, dl, cov_norm, op_bank = _rebuild(grow_snap)
                print(f"  GROW epoch {epoch}: {len(ds):,} tuples in {len(ds.scene_groups):,} scenes, "
                      f"scorer frames {len(scorer_bank.by):,}, cov_norm {cov_norm:.4f}"
                      + (f", ON-POLICY sets {len(op_bank.by):,} ({op_bank.n_incomplete} incomplete, "
                         f"{op_bank.n_superseded} superseded, NAVSIM drivable area on {op_bank.n_navsim_dac:,})"
                         if op_bank is not None else ""))
                if run_dir is not None:
                    _append_jsonl(run_dir / "metrics.jsonl", _bank_event())
            continue
        break

    print("")
    print(f"  scorer coverage: {n_cov:,} of {n_seen:,} samples carried PDM targets "
          f"({100.0*n_cov/max(n_seen,1):.1f} %)")
    print(f"  batches with NO scorer supervision at all: {n_uncovered} "
          f"(they contribute zero gradient, not a zero target)")
    if n_cov > 0:
        print("  assignment distance per candidate (the floor is set by the CANDIDATE SET, not by")
        print("  model quality -- teacher/lat should converge, over-curb/stopped should not):")
        print(f"      {'candidate':10s} {'n':>6s} {'whole run':>12s} "
              f"{'last 25 %':>12s}   (the trailing column is the one that answers the question)")
        for i, nm in enumerate(CAND_NAMES):
            tot, cnt = per_cand[i]
            ltot, lcnt = per_cand_late[i]
            if cnt:
                late = f"{ltot/lcnt:10.2f} m" if lcnt else f"{'n/a':>12s}"
                print(f"      {nm:10s} {cnt:6d} {tot/cnt:10.2f} m {late}")
    if n_cov == 0:
        print("  *** THE SCORER SAW NO REAL TARGETS. It trained against the zero placeholder and")
        print("  *** proposal selection at inference is still arbitrary. Do not report a selection")
        print("  *** result from this run.")
    drop = 100.0 * (1 - last / max(first, 1e-9))
    print(f"\n  traj L1: first {first:.4f} -> last {last:.4f}   ({drop:.1f} % reduction)")
    if a.overfit:
        ok = last < a.overfit_thresh
        print(f"  OVERFIT CONTROL: final L1 {last:.4f} < {a.overfit_thresh} ? "
              f"{'PASS -- the loop can learn' if ok else 'FAIL -- the loop cannot memorise 8 tuples'}")
        print("TRAIN_CONTROL_OK" if ok else "TRAIN_CONTROL_FAILED")
        return 0 if ok else 1
    if run_dir is not None:
        # order matters: resume state first, then the model, then the done-marker LAST, so a kill
        # anywhere in here leaves a run that a relaunch completes rather than one that lies
        _save_ckpt()
        fin = run_dir / "model_final.pt"
        ckpt_io.atomic_save({"format": ckpt_io.FORMAT_FULL, "model": ckpt_io.full_state(model),
                             "meta": dict(meta, step=step, epoch=epoch, finished_at=_now()), **_aux_ckpt()},
                            fin)
        fin_sha = ckpt_io.sha256_file(fin)
        summary = {"done": True, "steps": step, "epochs_completed": epoch,
                   "samples_seen": n_seen, "first_traj_L1": first, "last_traj_L1": last,
                   "scorer_cov": n_cov / max(n_seen, 1), "model_final": fin.name,
                   "model_final_sha256": fin_sha, "finished_at": _now()}
        tmp = run_dir / "summary.json.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=1)
        os.replace(tmp, run_dir / "summary.json")
        print(f"  saved {fin} (sha256 {fin_sha[:12]}) and summary.json (done=true)")
    if lab is not None:
        lab.close()
    print("TRAIN_DONE")
    return 0


def build_parser() -> argparse.ArgumentParser:
    """The trainer's argparse parser, built by a function so the launch gate (refe/gate_checks.py, G-DVB) can introspect every
    flag without running a training. A PURE MOVE of the former body of main(): no flag, default or help changed."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--backbone", default="vitl16", choices=sorted(BACKBONES))
    ap.add_argument("--weights", default="",
                    help="pretrained DINOv3 dir; default is derived from --backbone. "
                         "'none' = frozen RANDOM trunk (an ablation, never a reproduction).")
    # ⛔ THE DEFAULT MOVED 2026-09-21. `refe_targets` is the SINGLE-CAMERA, 8-D-ego bank and is now
    # incompatible with the model by construction; `refe_targets_4cam` is the rebuild. Leaving the
    # old path as the default would have made every no-argument run fail on a bank nobody meant to
    # use -- and before the ego guard existed, fail as an unreadable matmul error.
    ap.add_argument("--targets", default="D:/Projects/TanitAD/data/refe_targets_4cam")
    ap.add_argument("--scorer-targets",
                    default="D:/Projects/TanitAD/data/refe_scorer_targets_full",
                    help="six-component PDM targets from build_scorer_targets.py; absent => "
                         "the zero placeholder, and selection at inference stays arbitrary")
    ap.add_argument("--images", default=None)
    ap.add_argument("--calib", default=None,
                    help="calib_table.json (refe/calib_table.py): each tuple's OWN camera rig for "
                         "the PETR position embedding. Absent -> the one baked rig (an ablation).")
    ap.add_argument("--max-missing-images", type=float, default=0.001,
                    help="fraction of tuples allowed to name an unresolvable frame; they are "
                         "DROPPED and counted. Above it the load is REFUSED as a broken join.")
    ap.add_argument("--grow", action="store_true",
                    help="GROWING BANK: re-read --targets/--scorer-targets at every epoch boundary "
                         "(up to a byte snapshot kept in the checkpoint, so resume stays exact) -- "
                         "training runs while the augmentation search and the scorer still produce "
                         "rows. The files must be append-only (code/grow_assemble.py).")
    ap.add_argument("--grow-scenes", type=int, default=0,
                    help="with --grow --epochs: the FINAL scene count the schedule is sized for")
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--overfit", action="store_true")
    ap.add_argument("--overfit-n", type=int, default=8)
    ap.add_argument("--overfit-thresh", type=float, default=0.5)
    ap.add_argument("--spread", action="store_true",
                    help="sample the overfit tuples ACROSS the bank instead of the first N "
                         "consecutive frames -- see TargetBank for why the default is weak")
    ap.add_argument("--break-optimizer", action="store_true")
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--batch", type=int, default=8)
    # ⛔ ACCUMULATION IS NOT A SPEED KNOB HERE -- IT DECIDES WHETHER THE 64 PROPOSALS EXIST.
    # The WTA objective gives gradient to exactly ONE proposal per SAMPLE, so a step at batch 4
    # touches at most 4 of 64 and the rest never move. MEASURED: at batch 2 the winner was 1/2 on
    # EVERY logged step -- both samples picking the same proposal. Their batch was 256, data
    # parallel over 16 H20s; on one A40 the same effective batch is `--batch 4 --accum 64`.
    # ⚠️ It does NOT reproduce batch 256 in every respect: the forward statistics are still those
    # of the micro-batch. It reproduces the GRADIENT, which is the part WTA coverage depends on.
    ap.add_argument("--accum", type=int, default=1,
                    help="micro-batches per optimiser step; effective batch = batch x accum")
    # a single-camera ablation is legitimate (it is what every result before 2026-09-20 used) and
    # must not require a source edit -- the camera guard's own message now points here.
    ap.add_argument("--n-cameras", type=int, default=None,
                    help="override the rig size, e.g. 1 for the single-front-camera ablation")
    ap.add_argument("--no-undistort", dest="undistort", action="store_false",
                    help="ablation: unproject with an IDEAL pinhole, as before 2026-09-21")
    ap.add_argument("--scorer-sees-trunk", dest="detach_scorer_context", action="store_false",
                    help="ablation: let the PDM loss reach the backbone LoRA (paper does not say)")
    ap.add_argument("--lr", type=float, default=2e-4,
                    help="PAPER: initial 2e-4, decayed to zero via cosine annealing")
    ap.add_argument("--weight-decay", type=float, default=0.01,
                    help="PAPER Table A12: 0.01. Was 1e-4 here -- a 100x error, read as "
                         "'not stated' by an earlier review and refuted by reading the table.")
    ap.add_argument("--no-cosine", dest="cosine", action="store_false",
                    help="ablation only -- the paper's schedule is cosine to zero")
    ap.set_defaults(cosine=True)
    ap.add_argument("--epoch-unit", choices=("scenes", "rows"), default="scenes",
                    help="what ONE epoch passes over. 'scenes' (default, the paper's unit -- Table "
                         "A12 counts its data in scenes; PI 2026-09-23, R24): every scene once per "
                         "epoch, its goal-augmented targets taking turns across epochs. 'rows': "
                         "every stored target every epoch -- 1.71x the paper's budget at tau 0.3.")
    ap.add_argument("--epochs", type=int, default=0,
                    help="PAPER: 25 epochs at batch 256. When set, --steps is DERIVED as "
                         "epochs * ceil(epoch length/(batch*accum)) -- the epoch length being the "
                         "scene count under --epoch-unit scenes -- so the paper's schedule is stated "
                         "in its own unit; the cosine T_max then spans the whole run.")
    ap.add_argument("--score-w", type=float, default=0.1)
    ap.add_argument("--log-every", type=int, default=25)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--amp", choices=("none", "bf16"), default="none",
                    help="bf16 autocast of the forward (losses stay FP32). MEASURED 3.5x on the A40. "
                         "A DEPARTURE from the paper's FP32 -- recorded, and part of the resume identity")
    ap.add_argument("--tf32", action="store_true",
                    help="TF32 tensor-core matmuls for FP32 math (A40: 1.27x at FP32)")
    ap.add_argument("--fused-adam", action="store_true", help="torch's fused AdamW kernel")
    ap.add_argument("--compile", action="store_true",
                    help="torch.compile the frozen-trunk backbone in place (keys unchanged). A40: "
                         "bf16 0.366 -> 0.220 s/sample")
    ap.add_argument("--workers", type=int, default=0,
                    help="DataLoader workers decoding JPEGs off the critical path (order unchanged)")
    ap.add_argument("--out", default=None,
                    help="RUN DIRECTORY: config.json, metrics.jsonl, ckpt_last.pt, "
                         "snap_epochNNN.pt, model_final.pt, summary.json. REQUIRED for any real "
                         "run (> 500 steps or --epochs); without it nothing is saved.")
    ap.add_argument("--resume", action="store_true",
                    help="continue <out>/ckpt_last.pt if present (start fresh if absent). Refused "
                         "if the run's identity (defining args, bank content, trunk) changed.")
    ap.add_argument("--ckpt-every-min", type=float, default=20.0,
                    help="wall-clock checkpoint cadence, taken at optimiser-step boundaries")
    ap.add_argument("--ckpt-every-steps", type=int, default=0,
                    help="additionally checkpoint every N optimiser steps (0 = off)")
    ap.add_argument("--halt-after-steps", type=int, default=0,
                    help="TEST ONLY: exit right after the checkpoint at this step, to prove that "
                         "halt + --resume is bit-identical to an uninterrupted run")
    ap.add_argument("--scorer-mode", choices=("fixed", "onpolicy"), default="fixed",
                    help="fixed = the banked candidate set attached to the nearest proposal (the "
                         "declared departure); onpolicy = the paper's supervision, the student's OWN "
                         "proposals scored by the teacher (PI decision 2026-09-26, B)")
    ap.add_argument("--onpolicy-targets", default=None,
                    help="directory of onpolicy_*.jsonl written by onpolicy_label.py (onpolicy mode)")
    ap.add_argument("--declare-change", action="append", default=[], metavar="ARG",
                    help="an identity argument (e.g. scorer_mode) allowed to DIFFER on --resume: a "
                         "deliberate mid-run recipe change, printed and logged as an event")
    ap.add_argument("--init-from", default=None,
                    help="PREREG_P2: warm-start from a trained REFe checkpoint (FULL strict, or PARTIAL) instead of fresh "
                         "heads; the optimiser and schedule start fresh. Part of the run identity.")
    ap.add_argument("--pdm-labels", default=None,
                    help="PREREG_P2 / SFT-4: dir of pdm_*.jsonl (refe/onpolicy_relabel_pdm.py) -- NAVSIM PDM targets of "
                         "the executed plans replace all six components of the sets they were computed on")
    ap.add_argument("--pdm-only", action="store_true",
                    help="with --pdm-labels: the scorer is trained ONLY on sets carrying PDM targets (no mixed sources)")
    # ---- P6 (SPEC_P6_PAPER_FAITHFUL.md section 2). EVERY default below reproduces P2 / SFT-4 behaviour bit for bit; the P6 argv NAMES each one.
    ap.add_argument("--yaw-wrap", choices=("on", "off"), default="on",
                    help="D5. on = the yaw error is wrapped to (-pi, pi] (today's behaviour); off = the paper's literal L1 on the raw yaw difference. "
                         "PI ruling P6-Y is OPEN: the P6 argv must name it, the default does not decide.")
    ap.add_argument("--nav-mode", choices=("goal", "command"), default="goal",
                    help="D6. goal = two Fourier goal points (P2/SFT-4); command = the paper's discrete navigation command (cmd_embed; no goal encoder is built)")
    ap.add_argument("--labeller", choices=("bank", "online"), default="bank",
                    help="D1. bank = the banked/on-policy label sources (unchanged); online = NAVSIM PDM targets on each sample's OWN current proposals, "
                         "computed by a CPU pool while the next forward runs (deferred score backward, lag 0)")
    ap.add_argument("--label-backend", choices=("pdm", "synthetic"), default="pdm",
                    help="--labeller online: pdm = NAVSIM's simulator on the D9 metric cache; synthetic = a deterministic analytic CONTROL (rehearsal/tests; "
                         "the P6 launch profile forbids it)")
    ap.add_argument("--label-workers", type=int, default=12, help="--labeller online: labeller pool size (M-LAB: 12 workers sustain >= 2x the 4.49 sets/s needed)")
    ap.add_argument("--label-chunks", type=int, default=1,
                    help="--labeller online: score each sample's proposals as this many jobs of contiguous proposals (SPEC_P6 3.1: a set may be split across workers "
                         "for LATENCY; labels are per proposal, so unchanged -- G-LIVE-LAB's identity check re-proves it). 1 = one job per set (the default)")
    ap.add_argument("--label-timeout-s", type=float, default=900.0, help="--labeller online: a micro-batch whose labels are not back in this long raises")
    ap.add_argument("--label-python", default="", help="--labeller online: interpreter for the pdm workers if the NAVSIM stack lives in another venv")
    ap.add_argument("--metric-cache", default=None, help="--labeller online: the D9 parts directory (refe/build_metric_cache.py) <log>/<token>[__twin].pkl.xz")
    # ---- L_field (eval/PREREG_AUX_FIELD_LOSS_DRAFT.md, PI decision D-AUX-4). EVERY default reproduces the trainer without the term bit for bit; an arm that means the term NAMES --w-field.
    ap.add_argument("--w-field", type=float, default=0.0,
                    help="weight of L_field, the hinge relu(margin - SDF_gt(corner)) on the footprint corners of ALL 64 proposals (refe/field_loss.py). 0.0 = OFF: the term is not "
                         "computed. Set once by the committed gradient-norm rule (refe/weight_rule.py), never tuned on PDMS. Needs --field-labels.")
    ap.add_argument("--field-margin", type=float, default=0.25, help="L_field's margin in metres (registered 0.25)")
    ap.add_argument("--field-interp", choices=("5hz", "navsim2hz"), default="5hz",
                    help="L_field's pose up-sampling: 5hz = 20 poses at 5 Hz -> 10 Hz linear from the origin (registered); navsim2hz = NAVSIM's own 2 Hz chain")
    ap.add_argument("--field-labels", default=None,
                    help="the int8 SDF label store directory (aux_label_store.py; the pinned store). The loader then also delivers (sdf, valid) per sample. Absent = the item tuple "
                         "is unchanged.")
    ap.add_argument("--field-shuffle-seed", type=int, default=None,
                    help="the label-shuffled CONTROL arm: a derangement of the label keys with this seed (registered 20261011). Needs --field-labels.")
    # ---- WP YAW (TanitAD-artifacts/yawrate_wp/PLAN.md): a REAL ego[4]. The default (None) is the trainer without the feature, bit for bit.
    ap.add_argument("--ego-yaw-table", default=None,
                    help="a refe/ego_yaw_table.py table (gzipped JSON {lidar_pc token: ego_pose.angular_rate_z, rad/s CCW+}). Each sample's ego[4] (yaw_rate) is then set to YAW_SCALE (10.0) x the table value for the row's "
                         "token; ego[5] (steering) is left as the bank has it. A bank row whose token is missing from the table REFUSES the launch. Absent = ego[4] is whatever the bank holds (0.0). "
                         "The checkpoint's meta then carries ego_yaw='nuplan_angular_rate_z' and the table sha256.")
    # ---- P5-C (scorer_gym_20261107/p5c/P5C_READINESS.md section 3): the WTA target is the tracker-aware Tc20s label. The default (None) is the trainer without the feature, bit for bit.
    ap.add_argument("--traj-label-table", default=None,
                    help="a refe/traj_label_table.py table (gzipped JSON {log|token|rank|sha256(row traj): [T, 3] label}). Each TRAIN row's WTA target (item[3]) is then the table's label for the row; a row the table does "
                         "not carry keeps its raw traj (coverage printed), a row whose traj sha256 differs from the one the label was computed from REFUSES the launch. The held-out / eval banks never get it. "
                         "NOT used by the scorer / on-policy paths (train.py reads r['traj'] there at the scorer-bank and on-policy-bank loaders; refe_p6 / refe_p7 forbid those flags). "
                         "Absent = the raw traj. The checkpoint's meta then carries traj_label_table_sha256 and the coverage.")
    # ---- P7.1 (SPEC_AUX_DRIVABLE_HEAD.md section 4): the training-only drivable-area head. EVERY default builds nothing; an arm that means the head NAMES --aux-drv AND --w-aux-drv > 0.
    AUX.add_aux_args(ap)
    ap.add_argument("--preflight", action="store_true",
                    help="build banks + model, load and check the checkpoint, then exit WITHOUT "
                         "writing anything (safe against a live run directory); prints PREFLIGHT_OK")
    return ap


def main():
    sys.exit(run(build_parser().parse_args()))


if __name__ == "__main__":
    main()
