import pathlib
p = pathlib.Path("E:/Projects/TanitAD-artifacts/scorer_gym_20261107/p5c_launchkit/files/TanitAD Research Lab/Architecture & Inference/Research/2026-09-20-refe-plan/refe/test_traj_label_table.py")
s = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:70])
    s = s.replace(a, b)


rep('def make_table(root: Path, rows: list, name="t.json.gz", skip_idx=(), require=0.0, label_name="Tc20s-fixture", fn=label_of) -> str:',
    'def make_table(root: Path, rows: list, name="t.json.gz", skip_idx=(), require=0.0, label_name="Tc20s-fixture", fn=label_of, rank_policy="all") -> str:')
rep('''    tab, meta, _ = TLT.build_table(rows, labs, {"label_name": label_name}, require_coverage=require, allow_partial=bool(skip_idx))''',
    '''    tab, meta, _ = TLT.build_table(rows, labs, {"label_name": label_name}, require_coverage=require, allow_partial=bool(skip_idx), rank_policy=rank_policy)''')
rep('''{"label_name": "identity"}, 1.0)''', '''{"label_name": "identity"}, 1.0, rank_policy="identity")''', 2)
rep('''r3 = run("build", "--bank-dir", bank, "--labels", str(lj), "--out", str(td / "b.json.gz"))''',
    '''r3 = run("build", "--bank-dir", bank, "--labels", str(lj), "--out", str(td / "b.json.gz"), "--rank-policy", "all")''')
rep('''"--allow-partial", "--require-coverage", "1.0")''', '''"--allow-partial", "--require-coverage", "1.0", "--rank-policy", "all")''')
rep("""'differs_from_raw': 0, 'table_keys': len(tlt)}}""", """'differs_from_raw': 0, 'table_keys': len(tlt), 'differs_by_rank': {}, 'rank_policy': 'all'}}""")
rep('''        ok(mt.get("traj_label_table_sha256") == sha and mt["traj_label_coverage"]["covered"] == 7, mt)''',
    '''        ok(mt.get("traj_label_table_sha256") == sha and mt["traj_label_coverage"]["covered"] == 7, mt)
        ok(mt.get("traj_label_rank_policy") == "all", "the checkpoint meta carries the table's declared rank policy (card 10.3 G-CKPT)")''')

NEW = r'''

# ------------------------------------------------------------------------------------------------ S6 the RANK POLICY and the sha-bound labeller meta (PREREG_P5C 4.3; the MM's open item)
def _rank0_label(r: dict) -> list:
    """the `rank0` policy's label: rank-0 rows get the stand-in label, rank-1 rows keep their raw traj (the card's `raw_rank1` identity rows)."""
    return label_of(r) if int(r.get("rank", 0)) == 0 else [[float(x) for x in p] for p in r["traj"]]


def _meta_json(td: Path, bank: str, **over) -> str:
    """what the pod's gate set writes (p5c_table_gates.meta_fields), minimal: shaped like table_meta_fields.json."""
    rows = TLT.read_bank_rows(bank)
    d = {"label_name": "Tc20s", "schema": "traj-label-table-v1", "interp": "cubic", "iters": 3, "n_rows": len(rows), "n_raw_fallback": 0, "n_differs_per_rank": {"0": 5, "1": 0},
         "rank_policy": "rank0", "code_blob_sha1": {"x.py": "ab" * 20}, "bank_files_sha256": TLT.bank_files_sha256(bank), "build_host": "fixture",
         "table_sha256": "UNKNOWN until traj_label_table.py build; the pod runner appends it (P5C_LABEL_TABLE_SHA256)"}
    d.update(over)
    p = td / f"meta_{len(list(td.glob('meta_*.json')))}.json"
    p.write_text(json.dumps({k: v for k, v in d.items() if v is not None}, indent=1), encoding="utf-8", newline="\n")
    return str(p)


def chk_rank_policy():
    import train as T
    td = Path(tempfile.mkdtemp(prefix="tlt_rp_"))
    try:
        bank = make_bank(td)
        rows = TLT.read_bank_rows(bank)
        n1 = sum(1 for r in rows if r["rank"] == 1)
        ok(n1 == 2 and len(rows) == 7)
        # (1) a table with NO declared policy, or an unknown one, is REFUSED by the one reader (the old silent default is the failure)
        labs = {TLT.row_triple(r): (label_of(r), None) for r in rows}
        tab, meta, _ = TLT.build_table(rows, labs, {"label_name": "x"})
        ok("rank_policy" not in meta)
        TLT.save(td / "nopol.json.gz", tab, meta)
        e = raises(TLT.TableRefused, TLT.apply_to_rows, TLT.load(td / "nopol.json.gz"), rows)
        ok(e is not None and "rank_policy" in str(e), "no declared rank_policy -> refused at the reader")
        TLT.save(td / "badpol.json.gz", tab, dict(meta, rank_policy="rank1"))
        ok(raises(TLT.TableRefused, TLT.apply_to_rows, TLT.load(td / "badpol.json.gz"), rows) is not None, "an unknown policy value is refused")
        ok(raises(TLT.TableRefused, TLT.build_table, rows, labs, None, 0.0, False, "rank1") is not None, "build refuses an unknown policy")
        # (2) `all`: rank-1 rows may differ; the reader reports the split per rank
        pa = make_table(td, rows, name="all.json.gz", rank_policy="all")
        res = TLT.apply_to_rows(TLT.load(pa), rows)
        ok(res["coverage"]["rank_policy"] == "all" and res["coverage"]["differs_by_rank"] == {"0": 5, "1": 2} and res["coverage"]["covered"] == 7, res["coverage"])
        # (3) `rank0`: rank-1 rows carry their raw traj as labels; coverage stays 100 % (7 keys), the differing rows are exactly the rank-0 ones
        p0 = make_table(td, rows, name="r0.json.gz", rank_policy="rank0", fn=_rank0_label, require=1.0)
        t0 = TLT.load(p0)
        ok(t0.meta["rank_policy"] == "rank0" and len(t0) == 7 and t0.meta["require_coverage"] == 1.0)
        res0 = TLT.apply_to_rows(t0, rows)
        ok(res0["coverage"]["coverage"] == 1.0 and res0["coverage"]["differs_by_rank"] == {"0": 5} and res0["coverage"]["differs_from_raw"] == 5, res0["coverage"])
        # (4) the policy is ENFORCED, in both directions.  (a) build: a rank-1 label that is not raw under `rank0` is refused; `identity` refuses any difference
        ok(raises(TLT.TableRefused, make_table, td, rows, "x1.json.gz", (), 0.0, "t", label_of, "rank0") is not None, "build: rank0 with a changed rank-1 label is refused")
        ok(raises(TLT.TableRefused, make_table, td, rows, "x2.json.gz", (), 0.0, "t", label_of, "identity") is not None, "build: identity with a changed label is refused")
        # (b) READER: a file that DECLARES rank0 but holds a changed rank-1 label (a forged / flipped policy) is refused at the bank -- the card's `rank_policy flipped` RED
        ta = TLT.load(pa)
        TLT.save(td / "flip.json.gz", ta.labels, dict(ta.meta, rank_policy="rank0"))
        e = raises(TLT.TableRefused, TLT.apply_to_rows, TLT.load(td / "flip.json.gz"), rows)
        ok(e is not None and "rank_policy 'rank0'" in str(e) and "rank-1" in str(e), "reader: a flipped policy is refused")
        TLT.save(td / "flip2.json.gz", ta.labels, dict(ta.meta, rank_policy="identity"))
        ok(raises(TLT.TableRefused, TLT.apply_to_rows, TLT.load(td / "flip2.json.gz"), rows) is not None, "reader: an identity claim over changed labels is refused")
        # the other way (a rank0 table declared `all`) is honest (it only claims less) and passes
        TLT.save(td / "flip3.json.gz", t0.labels, dict(t0.meta, rank_policy="all"))
        ok(TLT.apply_to_rows(TLT.load(td / "flip3.json.gz"), rows)["coverage"]["differs_from_raw"] == 5)
        # (5) THE MM's OPEN ITEM, in numbers: a table that simply OMITS the rank-1 rows covers 5/7 of this bank (92,896 / 150,603 = 61.7 % at scale), and --require-coverage 1.0 REFUSES it,
        #     while the card's `rank0only` merge (rank-1 rows present as raw_rank1 identities) covers 7/7 and PASSES the same bar.
        r0_only = {TLT.row_triple(r): (label_of(r), None) for r in rows if r["rank"] == 0}
        ok(raises(TLT.TableRefused, TLT.build_table, rows, r0_only, None, 1.0, False, "rank0") is not None, "a rank-0-only labels file is refused at build under --require-coverage (no --allow-partial)")
        tab_p, meta_p, rep_p = TLT.build_table(rows, r0_only, {"label_name": "p"}, 1.0, True, "rank0")
        ok(rep_p["covered"] == 5 and rep_p["rows"] == 7)
        TLT.save(td / "r0only.json.gz", tab_p, meta_p)
        e = raises(TLT.TableRefused, TLT.apply_to_rows, TLT.load(td / "r0only.json.gz"), rows)
        ok(e is not None and "required" in str(e) and "5/7" in str(e).replace(",", ""), "the trainer-side reader refuses the omitted-rank-1 table at coverage 5/7 vs required 1.0")
        # (6) through the REAL loader (G-LIVE (a) under `rank0`): rank-0 rows = table label bit for bit, rank-1 rows = raw bit for bit; the `all` table moves the rank-1 rows
        cfg = cfg_for_bank()
        d0 = T.TargetBank(bank, None, cfg, synthetic=True)
        dr = T.TargetBank(bank, None, cfg, synthetic=True, traj_label_table=p0)
        da = T.TargetBank(bank, None, cfg, synthetic=True, traj_label_table=pa)
        ok(dr.traj_label_cov["rank_policy"] == "rank0" and dr.traj_label_cov["differs_by_rank"] == {"0": 5})
        for i, r in enumerate(dr.rows):
            if r["rank"] == 1:
                ok(torch.equal(dr[i][3], f32(r["traj"])) and torch.equal(dr[i][3], d0[i][3]), "rank0 policy: a rank-1 row's item[3] is the raw traj bit for bit")
                ok(not torch.equal(da[i][3], f32(r["traj"])), "twin: under `all` the rank-1 row IS relabelled")
            else:
                ok(torch.equal(dr[i][3], f32(label_of(r))) and not torch.equal(dr[i][3], d0[i][3]), "rank0 policy: a rank-0 row's item[3] is the table's label")
        # a bank handed a policy-violating table refuses AT CONSTRUCTION (SystemExit), not at some later step
        try:
            T.TargetBank(bank, None, cfg, synthetic=True, traj_label_table=str(td / "flip.json.gz"))
        except SystemExit as e:
            ok("rank_policy" in str(e), str(e))
        else:
            ok(False, "a flipped-policy table must refuse the bank")
    finally:
        shutil.rmtree(td, ignore_errors=True)


def chk_meta_json():
    td = Path(tempfile.mkdtemp(prefix="tlt_mj_"))
    try:
        bank = make_bank(td)
        rows = TLT.read_bank_rows(bank)
        lj = td / "labels.jsonl"
        lj.write_text("".join(json.dumps({"log_name": r["log_name"], "token": r["token"], "rank": r["rank"], "label": _rank0_label(r), "traj_sha256": TLT.traj_sha256(r["traj"])}) + "\n" for r in rows),
                      encoding="utf-8", newline="\n")
        cmd = [sys.executable, str(HERE / "traj_label_table.py")]
        env = dict(os.environ, PYTHONIOENCODING="utf-8")

        def run(*args):
            return subprocess.run(cmd + list(args), capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)

        def build(out, mj=None, policy="rank0", name="Tc20s"):
            a = ["build", "--bank-dir", bank, "--labels", str(lj), "--out", str(td / out), "--require-coverage", "1.0", "--label-name", name]
            if policy:
                a += ["--rank-policy", policy]
            if mj:
                a += ["--meta-json", mj]
            return run(*a)
        # the policy has NO default
        r = build("n.json.gz", policy=None)
        ok(r.returncode == 2 and "--rank-policy" in r.stderr, "build without --rank-policy is refused (argparse, rc 2)")
        # a good meta-json is sha-bound: the table carries the file's sha256 and its content, minus the placeholder table_sha256
        mj = _meta_json(td, bank)
        r1 = build("a.json.gz", mj)
        ok(r1.returncode == 0, r1.stdout + r1.stderr)
        ta = TLT.load(td / "a.json.gz")
        ok(ta.meta["labeller_meta_sha256"] == TLT.sha256_file(mj) and ta.meta["rank_policy"] == "rank0" and ta.meta["label_name"] == "Tc20s", ta.meta)
        ok(ta.meta["labeller_meta"]["code_blob_sha1"] == {"x.py": "ab" * 20} and "table_sha256" not in ta.meta["labeller_meta"] and "rank_policy" not in ta.meta["labeller_meta"])
        ok(r1.returncode == 0 and run("verify", "--table", str(td / "a.json.gz"), "--bank-dir", bank).returncode == 0)
        v = json.loads(run("verify", "--table", str(td / "a.json.gz"), "--bank-dir", bank).stdout)
        ok(v["rank_policy"] == "rank0" and v["differs_by_rank"] == {"0": 5} and v["coverage"] == 1.0, v)
        # SHA-BOUND: one changed byte in the meta file changes the table (sha256 of the table file) and its recorded meta sha
        mj2 = _meta_json(td, bank, build_host="another-host")
        r2 = build("b.json.gz", mj2)
        ok(r2.returncode == 0 and TLT.sha256_file(td / "a.json.gz") != TLT.sha256_file(td / "b.json.gz"), "the table's sha256 covers the labeller meta")
        ok(TLT.load(td / "b.json.gz").meta["labeller_meta_sha256"] == TLT.sha256_file(mj2) != ta.meta["labeller_meta_sha256"])
        # without --meta-json the table builds but carries NO labeller meta (nothing is claimed that is not bound)
        r3 = build("c.json.gz")
        ok(r3.returncode == 0 and "labeller_meta_sha256" not in TLT.load(td / "c.json.gz").meta)
        # refusals: a meta about another table / policy / row count / bank / carrying a builder-owned field
        for what, over in (("label name", {"label_name": "P5R"}), ("rank policy", {"rank_policy": "all"}), ("row count", {"n_rows": 7 * 10}),
                           ("bank sha", {"bank_files_sha256": {"targets_rank0.jsonl": "0" * 64, "targets_rank1.jsonl": "1" * 64}}), ("owned field", {"covered": 7})):
            rr = build("z.json.gz", _meta_json(td, bank, **over))
            ok(rr.returncode == 2 and "REFUSED" in rr.stderr and "--meta-json" in rr.stderr, (what, rr.stderr))
        ok(not (td / "z.json.gz").exists(), "a refused build writes nothing")
        rr = build("z.json.gz", str(td / "labels.jsonl"))
        ok(rr.returncode == 2, "a labels file given as the meta is refused (it is not a JSON object)")
        # the policy handed to the builder is checked against the labels: `rank0` over labels that change a rank-1 row is refused by the CLI
        lj.write_text("".join(json.dumps({"log_name": r["log_name"], "token": r["token"], "rank": r["rank"], "label": label_of(r)}) + "\n" for r in rows), encoding="utf-8", newline="\n")
        rr = build("w.json.gz", _meta_json(td, bank))
        ok(rr.returncode == 2 and "rank_policy" in rr.stderr, rr.stderr)
        rr = build("w2.json.gz", _meta_json(td, bank, rank_policy="all"), policy="all")
        ok(rr.returncode == 0, rr.stderr)
    finally:
        shutil.rmtree(td, ignore_errors=True)


def chk_dvb_policy_pin():
    """G-DVB's rows for the P5-C pins: the table's declared rank policy and the base checkpoint's sha256 (a wrong pin is a red row)."""
    import gate_checks as C
    td = Path(tempfile.mkdtemp(prefix="tlt_pin_"))
    try:
        bank = make_bank(td)
        tp = make_table(td, TLT.read_bank_rows(bank), name="r0.json.gz", rank_policy="rank0", fn=_rank0_label)
        b_argv, b = _build(td, ("--traj-label-table", tp))
        prof = {**_prof(), "expect_schedule": None}
        a = b.args
        rows_ok = C.traj_label_dvb_rows(a, b, {"traj_label_sha256": TLT.sha256_file(tp), "traj_label_rank_policy": "rank0"})
        ok(all(r["ok"] for r in rows_ok) and any(r["how"].startswith("the table's meta.rank_policy") for r in rows_ok), rows_ok)
        rows_bad = C.traj_label_dvb_rows(a, b, {"traj_label_rank_policy": "all"})
        ok([r["ok"] for r in rows_bad if r["how"].startswith("the table's meta.rank_policy")] == [False], rows_bad)
        ev = C.check_dvb(b_argv, b, None, {**prof, "traj_label_rank_policy": "all"})
        ok(ev["status"] == "FAIL" and "--traj-label-table" in " ".join(ev["reasons"]), ev["reasons"])
        ev = C.check_dvb(b_argv, b, None, {**prof, "traj_label_rank_policy": "rank0"})
        ok(ev["status"] == "PASS", ev["reasons"])
        # init_from pin: the base file's sha256
        base = td / "base.pt"
        base.write_bytes(b"not a checkpoint, only bytes for a sha256")
        from types import SimpleNamespace
        ns = SimpleNamespace(init_from=str(base))
        sha = TLT.sha256_file(base)
        ok(C.p5c_init_rows(ns, {"init_from_sha256": sha})[0]["ok"] is True)
        ok(C.p5c_init_rows(ns, {"init_from_sha256": "0" * 64})[0]["ok"] is False, "a different checkpoint is a red row (card 10.1 RED mutation)")
        ok(C.p5c_init_rows(ns, {}) == [] and C.p5c_init_rows(SimpleNamespace(init_from=None), {"init_from_sha256": sha}) == [], "no pin / no flag: no row (every other profile unchanged)")
        ok(C.p5c_init_rows(SimpleNamespace(init_from=str(td / "missing.pt")), {"init_from_sha256": sha})[0]["ok"] is False)
        import inspect
        ok("p5c_init_rows(a, profile)" in inspect.getsource(C.dvb_rows), "dvb_rows carries the base-checkpoint row (source-level: the full row needs a real warm start)")
    finally:
        shutil.rmtree(td, ignore_errors=True)
'''
marker = "\n\ndef chk_no_scipy():"
assert s.count(marker) == 1
s = s.replace(marker, NEW + marker)
rep('''          "no_scipy": chk_no_scipy}''', '''          "rank_policy": chk_rank_policy, "meta_json": chk_meta_json, "dvb_policy_pin": chk_dvb_policy_pin, "no_scipy": chk_no_scipy}''')

MUT = '''    ("traj_label_table.py", "            if pol == \\"identity\\" or (pol == \\"rank0\\" and rk != 0):\\n", "            if False:\\n", "rank_policy"),                                      # the reader stops enforcing the declared policy
    ("traj_label_table.py", "    if pol not in RANK_POLICIES:\\n", "    if False:\\n", "rank_policy"),                                                              # an undeclared / unknown policy is accepted again
    ("traj_label_table.py", "        if rank_policy == \\"identity\\" or (rank_policy == \\"rank0\\" and int(r.get(\\"rank\\", 0)) != 0):\\n", "        if False:\\n", "rank_policy"),   # build no longer checks the policy against the labels
    ("traj_label_table.py", "    if \\"bank_files_sha256\\" in d and d[\\"bank_files_sha256\\"] != want_files:\\n", "    if False:\\n", "meta_json"),                       # the meta is no longer bound to THIS bank
    ("traj_label_table.py", "        extra.update(labeller_meta=lm, labeller_meta_sha256=lm_sha)\\n", "        extra.update(labeller_meta=lm)\\n", "meta_json"),                     # the table no longer records the meta's sha256
    ("traj_label_table.py", "        if k in d and d[k] != want:\\n", "        if False:\\n", "meta_json"),                                                       # a meta about another label / policy / row count is accepted
    ("train.py", '            meta["traj_label_rank_policy"] = ds.traj_label_cov.get("rank_policy")', '            pass  # (mutant) ', "train_e2e"),                       # the checkpoint no longer states the policy
    ("gate_checks.py", "    rows += p5c_init_rows(a, profile)\\n", "", "dvb_policy_pin"),                                                                  # the base-checkpoint row is not wired in
    ("gate_checks.py", '    pol_pin = (profile or {}).get("traj_label_rank_policy")', '    pol_pin = None  # (mutant) ', "dvb_policy_pin"),                                  # the policy pin is no longer read
'''
rep('''    ("gate_checks.py", "    rows += traj_label_dvb_rows(a, b, profile)\\n", "", "dvb_flag_set"),                                                        # the G-DVB row is not wired in
''', '''    ("gate_checks.py", "    rows += traj_label_dvb_rows(a, b, profile)\\n", "", "dvb_flag_set"),                                                        # the G-DVB row is not wired in
''' + MUT)
p.write_text(s, encoding="utf-8", newline="\n")
print("ok")
