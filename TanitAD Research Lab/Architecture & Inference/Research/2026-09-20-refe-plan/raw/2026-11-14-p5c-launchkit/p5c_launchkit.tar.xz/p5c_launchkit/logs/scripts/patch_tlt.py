import sys, pathlib
K = pathlib.Path("E:/Projects/TanitAD-artifacts/scorer_gym_20261107/p5c_launchkit/files/TanitAD Research Lab/Architecture & Inference/Research/2026-09-20-refe-plan/refe/traj_label_table.py")
s = K.read_text(encoding="utf-8")


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:60])
    s = s.replace(old, new)


rep('''SCHEMA = "traj-label-table-v1"
''', '''SCHEMA = "traj-label-table-v1"
# THE RANK POLICY (PREREG_P5C 4.3: "the output goes into the table meta as `rank_policy` in {all, rank0}, and G-DVB checks it").  A table DECLARES it and the one reader (`apply_to_rows`) ENFORCES it on the rows:
#   all       every labelled row may differ from its raw traj (rank-0 and rank-1);
#   rank0     only RANK-0 rows may differ: every rank-1 row's label must equal its own raw traj bit for bit (the card's `raw_rank1` identity rows).  The table still HAS a key for every row, so
#             `require_coverage` 1.0 is met (the bank-wide coverage is NOT the rank-0 share, ~61.7 %, 92,896 / 150,603: the rank-1 rows are present, as identities);
#   identity  the control table (`identity` command): every label equals its raw traj.
# A table with NO `rank_policy`, or any other value, is REFUSED by the reader: an undeclared policy is the failure (a rank0-only claim that the file does not keep).
RANK_POLICIES = ("all", "rank0", "identity")
BUILD_OWNED_META = ("schema", "n_keys", "require_coverage", "bank_rows", "covered", "partial", "label_name", "labels_file", "rank_policy", "labeller_meta", "labeller_meta_sha256")
''')

rep('''def _check_label(label, traj, where: str):''', '''def same_as_raw(label, traj) -> bool:
    """the label is the row's own traj, value for value (the identity rows of the `rank0` policy and of the control table)."""
    return [[float(x) for x in p] for p in label] == [[float(x) for x in p] for p in traj]


def _check_label(label, traj, where: str):''')

rep('''    out: dict = {}
    n_diff = 0
    for i, r in enumerate(rows):
        lab = table.lookup(r)
        if lab is None:
            continue
        _check_label(lab, r["traj"], f"row {row_triple(r)}")
        out[i] = lab
        if lab != [list(map(float, p)) for p in r["traj"]]:
            n_diff += 1
    n = len(rows)
''', '''    pol = table.meta.get("rank_policy")
    if pol not in RANK_POLICIES:
        raise TableRefused(f"the table declares rank_policy {pol!r}, not one of {list(RANK_POLICIES)}: REFUSED (a table must say which ranks its labels may change; PREREG_P5C 4.3)")
    out: dict = {}
    n_diff = 0
    diff_by_rank: dict = {}
    for i, r in enumerate(rows):
        lab = table.lookup(r)
        if lab is None:
            continue
        _check_label(lab, r["traj"], f"row {row_triple(r)}")
        out[i] = lab
        same = same_as_raw(lab, r["traj"])
        rk = int(r.get("rank", 0))
        if not same:
            n_diff += 1
            diff_by_rank[str(rk)] = diff_by_rank.get(str(rk), 0) + 1
            if pol == "identity" or (pol == "rank0" and rk != 0):
                raise TableRefused(f"row {row_triple(r)}: the table declares rank_policy {pol!r} but this rank-{rk} row's label differs from its raw traj: REFUSED (the declared policy is not what the file holds)")
    n = len(rows)
''')
rep('''"table_keys": len(table), "table_sha256": table.sha256, "label": table.meta.get("label_name")}''',
    '''"table_keys": len(table), "table_sha256": table.sha256, "label": table.meta.get("label_name"), "rank_policy": pol, "differs_by_rank": diff_by_rank}''')

rep('''def build_table(rows: list, labels_by_triple: dict, meta_extra: dict | None = None, require_coverage: float = 0.0, allow_partial: bool = False):
    """rows = bank rows; labels_by_triple = {(log|token|rank): (label, optional traj_sha256 or None)}.  -> (labels {key: label}, meta, report)."""
    out: dict = {}''', '''def build_table(rows: list, labels_by_triple: dict, meta_extra: dict | None = None, require_coverage: float = 0.0, allow_partial: bool = False, rank_policy: str | None = None):
    """rows = bank rows; labels_by_triple = {(log|token|rank): (label, optional traj_sha256 or None)}.  -> (labels {key: label}, meta, report).
    `rank_policy` (RANK_POLICIES) is written into the meta and CHECKED against the labels handed in: `rank0` refuses a rank-1 row whose label is not its raw traj, `identity` any row's.  None writes none
    (a table without a policy is refused by the reader, apply_to_rows): the CLI never passes None."""
    if rank_policy is not None and rank_policy not in RANK_POLICIES:
        raise TableRefused(f"rank_policy {rank_policy!r} is not one of {list(RANK_POLICIES)}")
    out: dict = {}''')
rep('''        _check_label(lab, r["traj"], f"row {t}")
        out[f"{t}|{sha}"] = lab''', '''        _check_label(lab, r["traj"], f"row {t}")
        if rank_policy == "identity" or (rank_policy == "rank0" and int(r.get("rank", 0)) != 0):
            if not same_as_raw(lab, r["traj"]):
                raise TableRefused(f"{t}: rank_policy {rank_policy!r} declared, but this rank-{int(r.get('rank', 0))} row's label differs from its raw traj: REFUSED at build")
        out[f"{t}|{sha}"] = lab''')
rep('''    meta = dict(meta_extra or {}, require_coverage=float(require_coverage), bank_rows=len(rows), covered=len(out), partial=bool(missing))
''', '''    meta = dict(meta_extra or {}, require_coverage=float(require_coverage), bank_rows=len(rows), covered=len(out), partial=bool(missing))
    if rank_policy is not None:
        meta["rank_policy"] = rank_policy
''')

rep('''def verify(table_path: str, bank_dir: str) -> dict:''', '''def bank_files_sha256(bank_dir: str) -> dict:
    return {os.path.basename(p): sha256_file(p) for p in sorted(glob.glob(os.path.join(bank_dir, "targets_rank*.jsonl")))}


def load_labeller_meta(path: str, bank_dir: str, n_rows: int, label_name: str, rank_policy: str) -> tuple:
    """The labeller / gate set's own meta (`p5c_table_gates.py`'s table_meta_fields.json), SHA-BOUND into the table: -> (dict to embed as meta.labeller_meta, sha256 of the file's bytes).
    REFUSES a meta that is not about THIS build: another label name, another rank policy (the gates' decision vs the policy handed to the builder), another row count, another bank (the file's
    `bank_files_sha256` must equal the sha256 of the bank's own rank files), a field the builder owns (an overwrite of build facts), or one that is not a JSON object."""
    raw = Path(path).read_bytes()
    try:
        d = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as e:
        raise TableRefused(f"--meta-json {path}: not UTF-8 JSON ({e})")
    if not isinstance(d, dict):
        raise TableRefused(f"--meta-json {path}: not a JSON object")
    for k, want, what in (("label_name", label_name, "label name"), ("rank_policy", rank_policy, "rank policy"), ("n_rows", n_rows, "bank row count")):
        if k in d and d[k] != want:
            raise TableRefused(f"--meta-json {path}: its {what} is {d[k]!r}, this build's is {want!r}: the meta is about another table")
    want_files = bank_files_sha256(bank_dir)
    if "bank_files_sha256" in d and d["bank_files_sha256"] != want_files:
        raise TableRefused(f"--meta-json {path}: its bank_files_sha256 {d['bank_files_sha256']!r} is not this bank's {want_files!r}")
    clash = sorted(k for k in d if k in BUILD_OWNED_META and k not in ("label_name", "rank_policy"))
    if clash:
        raise TableRefused(f"--meta-json {path}: carries {clash}, fields the builder owns")
    keep = {k: v for k, v in d.items() if k not in ("label_name", "rank_policy", "table_sha256")}      # table_sha256 is the gates' placeholder ("UNKNOWN until build"): the table's own sha is the file's, never a field in it
    return keep, hashlib.sha256(raw).hexdigest()


def verify(table_path: str, bank_dir: str) -> dict:''')

rep('''    tab, meta, rep = build_table(rows, labels, {"label_name": a.label_name, "labels_file": os.path.basename(a.labels)}, a.require_coverage, a.allow_partial)
    sha = save(a.out, tab, meta)''', '''    extra = {"label_name": a.label_name, "labels_file": os.path.basename(a.labels)}
    if a.meta_json:
        lm, lm_sha = load_labeller_meta(a.meta_json, a.bank_dir, len(rows), a.label_name, a.rank_policy)
        extra.update(labeller_meta=lm, labeller_meta_sha256=lm_sha)
    tab, meta, rep = build_table(rows, labels, extra, a.require_coverage, a.allow_partial, rank_policy=a.rank_policy)
    sha = save(a.out, tab, meta)''')
rep('''    tab, meta, rep = build_table(rows, labs, {"label_name": "identity"}, 1.0)
    sha = save(a.out, tab, meta)''', '''    tab, meta, rep = build_table(rows, labs, {"label_name": "identity"}, 1.0, rank_policy="identity")
    sha = save(a.out, tab, meta)''')
rep('''    b.add_argument("--label-name", default="")
    b.add_argument("--allow-partial", action="store_true")''', '''    b.add_argument("--label-name", default="")
    b.add_argument("--allow-partial", action="store_true")
    b.add_argument("--rank-policy", required=True, choices=("all", "rank0"), help="REQUIRED, no default: which ranks the labels may change (PREREG_P5C 4.3). rank0 refuses a rank-1 label that is not its raw traj")
    b.add_argument("--meta-json", default="", help="the gate set's table_meta_fields.json: sha-bound into the table (meta.labeller_meta + labeller_meta_sha256); refused if it is about another label / policy / bank")''')
rep('''    python traj_label_table.py build    --bank-dir <dir> --labels <jsonl> --out T.json.gz [--require-coverage 1.0] [--label-name Tc20s] [--allow-partial]''',
    '''    python traj_label_table.py build    --bank-dir <dir> --labels <jsonl> --out T.json.gz --rank-policy all|rank0 [--meta-json table_meta_fields.json] [--require-coverage 1.0] [--label-name Tc20s] [--allow-partial]''')
rep('''    python traj_label_table.py identity --bank-dir <dir> --out T.json.gz           # label := the row's own traj (the control table: must reproduce flag-off bit for bit)''',
    '''    python traj_label_table.py identity --bank-dir <dir> --out T.json.gz           # label := the row's own traj (rank_policy "identity": the control table, must reproduce flag-off bit for bit)''')
K.write_text(s, encoding="utf-8", newline="\n")
print("ok")
