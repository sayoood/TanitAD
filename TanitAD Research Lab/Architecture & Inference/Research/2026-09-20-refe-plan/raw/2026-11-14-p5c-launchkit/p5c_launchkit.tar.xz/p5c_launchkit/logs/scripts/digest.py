import sys, json, hashlib
tree = sys.argv[1]
sys.path.insert(0, tree)
import launch_gate as L
d = {n: hashlib.sha256(repr(sorted(p.items())).encode("utf-8")).hexdigest() for n, p in L.PROFILES.items()}
json.dump(d, open(sys.argv[2], "w"), indent=0, sort_keys=True)
print(len(d))
