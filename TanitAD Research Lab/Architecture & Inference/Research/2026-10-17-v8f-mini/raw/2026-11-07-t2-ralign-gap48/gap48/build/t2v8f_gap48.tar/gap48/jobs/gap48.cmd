@echo off
rem GAP48 on box 2: the NuRec render gap on the 48 read scenes (descriptive). ONE job, safe mode. Launch: powershell -NoProfile -File D:\tanitad\launch.ps1 -Job D:\t2v8f\gap48\jobs\gap48.cmd -Log D:\t2v8f\logs\gap48.log
rem No labels and no goto on purpose: this file is LF-only, and cmd.exe can mis-read labels in an LF-only batch file.
call D:\tanitad\env.cmd
set "PYTHONPATH="
set "VCV=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if exist "%VCV%" (call "%VCV%" >nul) else (echo ZZNO-VCVARS)
set "CUDA_HOME=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8"
set "CUDA_PATH=%CUDA_HOME%"
set "PATH=%CUDA_HOME%\bin;%PATH%"
set "TORCH_CUDA_ARCH_LIST=8.9"
set "T2A_KIT=D:/t2a/box2_kit"
if not exist D:\t2v8f\pull_gap48 mkdir D:\t2v8f\pull_gap48
echo ===== GAP48 START %DATE% %TIME%
%RUNSAFE% %PY% -I -u D:\t2v8f\gap48\code\t2v8f_gap48.py all --pkg D:/t2v8f/pkg --gap D:/t2v8f/gap48 --kit D:/t2a/box2_kit --hf D:/tanitad/hf --scenes2 D:/t2v8f/scenes2 --scenes3 C:/t2v8f/scenes3 --pull D:/t2v8f/pull_gap48
echo ===== ZZJOB-END %DATE% %TIME% rc=%ERRORLEVEL%
